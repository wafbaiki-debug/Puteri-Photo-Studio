# Puteri Photo Studio - Fiuu integration package

This package adds two checkout routes and admin device notifications:

1. **Fiuu Hosted Payment Page** for online banking / FPX and e-wallet channels enabled for the studio's Fiuu merchant account.
2. **Manual Maybank transfer** as a fallback, with receipt upload and owner verification.

The customer chooses the route after reserving a slot. The Fiuu route posts a server-generated form to Fiuu's hosted page. The hosted page displays the payment channels available to this merchant account; the customer selects a bank or e-wallet there. The app does not hard-code a bank list because the enabled channels are controlled by Fiuu and the merchant profile. Admin alerts use browser push notifications because the studio uses one WhatsApp number only.

## Manual Maybank details

- Bank: Maybank
- Account holder: PUTERI NORSYAHIRA NATASYA BINTI SUHAMI
- Account number: 162786160739

The Maybank details above are only for the manual-transfer fallback. Fiuu settlement goes to the settlement bank account configured separately in the Fiuu merchant portal.

## Project files

- `index.html` / `Puteri-Photo-Studio-Ujian-Android.html` - customer and admin web app with Fiuu/manual payment selection.
- `manifest.webmanifest`, `icon.svg`, `sw.js` - Android-installable PWA shell. Booking, Supabase and Fiuu functions still require an internet connection.
- `schema.sql` - complete database schema for a new Supabase project.
- `supabase/migrations/20261030_fiuu_payment_integration.sql` - migration for an existing Puteri Photo Studio database.
- `supabase/functions/create-fiuu-payment` - creates a signed hosted-payment form using the booking amount from Supabase.
- `supabase/functions/fiuu-notify` - server-to-server payment notification handler.
- `supabase/functions/fiuu-callback` - deferred-status callback handler.
- `supabase/functions/fiuu-return` - redirects the browser back to the app without treating the browser return as proof of payment.
- `supabase/functions/check-fiuu-payment` - safely checks the status after the browser returns.
- `supabase/functions/_shared/fiuu.ts` - shared Fiuu signature verification and idempotent update logic.
- `supabase/config.toml` - public webhook/return and push function settings. The functions validate their own references and signatures.
- `supabase/functions/manage-admin-push-subscription` - owner-only device subscribe/unsubscribe and push test endpoint.
- `supabase/functions/notify-admin-push` - server-to-server booking webhook that sends Web Push notifications to subscribed admin devices.
- `supabase/migrations/20261030_admin_push_notifications.sql` - private device subscriptions and push delivery log.
- `supabase/verify-fiuu-installation.sql` - read-only checks for the database migration and account details.
- `supabase/verify-push-installation.sql` - read-only checks for push tables, Realtime publication and registered devices.

## 1. Apply the database

### Existing Supabase project

1. Open Supabase Dashboard -> SQL Editor.
2. Run `supabase/migrations/20261030_fiuu_payment_integration.sql` once.
3. Check that `public.bookings` has `payment_method` and `payment_status` columns.
4. Check that `public.fiuu_payments` exists and RLS is enabled.

### New Supabase project

Run the updated root `schema.sql` instead of the migration. Do not run both unless you are deliberately reconciling an existing database.

## 2. Obtain Fiuu merchant credentials

The studio must first have an approved Fiuu e-commerce merchant account and Hosted Payment Page access. Obtain these values directly from Fiuu / the merchant portal:

- Merchant ID (MID)
- Verify Key
- Secret Key
- The exact Hosted Payment Page form action URL for the merchant environment (sandbox or production)
- Confirmation that the required channels are enabled: Malaysia online banking / FPX and Touch 'n Go eWallet if available for this merchant profile
- Confirmation of the current request and response signature settings, including whether Extended VCode is enabled

Do not send the Verify Key or Secret Key in this chat. Store them only as Supabase Edge Function secrets.

## 3. Set Supabase Edge Function secrets

Use the Supabase CLI from the project root. Replace placeholders locally; never commit the real values:

```sh
supabase secrets set \
  FIUU_MERCHANT_ID="YOUR_MERCHANT_ID" \
  FIUU_VERIFY_KEY="YOUR_VERIFY_KEY" \
  FIUU_SECRET_KEY="YOUR_SECRET_KEY" \
  FIUU_PAYMENT_URL="https://THE_EXACT_HOSTED-PAYMENT-URL-SUPPLIED-BY-FIUU" \
  PUBLIC_APP_URL="https://YOUR-DEPLOYED-STUDIO-APP" \
  FIUU_EXTENDED_VCODE="false"
```

`FIUU_PAYMENT_URL` is deliberately not guessed in this package. Use the exact action URL issued for the merchant account and environment by Fiuu. If the URL contains `{merchant_id}`, the function replaces that placeholder with the MID.

`SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` are read from the Supabase Edge Function environment. Never put the service-role key or Fiuu Secret Key in the browser app.

## 4. Deploy Edge Functions

```sh
supabase functions deploy create-fiuu-payment
supabase functions deploy fiuu-notify
supabase functions deploy fiuu-callback
supabase functions deploy fiuu-return
supabase functions deploy check-fiuu-payment
```

Configure the following URLs in the Fiuu merchant portal / integration profile, as applicable:

- Return URL: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/fiuu-return`
- Notification URL: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/fiuu-notify`
- Callback URL: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/fiuu-callback`

The generated Return URL includes a per-payment order reference and random return token. The browser return only displays status; it does not confirm a booking.

**IPN note:** do not enable an additional IPN mode in the Fiuu portal until Fiuu confirms the required acknowledgement handshake for this merchant profile. This package handles the standard notification and callback endpoints; it does not implement an optional separate IPN `returnipn.php` handshake.

## 5. Connect the web app to Supabase

Edit `config.js` with the Supabase Project URL, public anon/publishable key, and VAPID public key:

```js
window.STUDIO_CONFIG = {
  supabaseUrl: "https://YOUR_PROJECT_REF.supabase.co",
  supabaseAnonKey: "YOUR_PUBLIC_ANON_OR_PUBLISHABLE_KEY",
  demoMode: false
};
```

The public anon/publishable key is intended for browser use. Never use the service-role key here. Publish the app on HTTPS. On Android Chrome, open the deployed URL and choose **Install app** / **Add to Home screen**. The service worker caches the app shell only; booking and payment actions still require internet access.

## 6. Payment behaviour

- The app creates a 15-minute booking hold before showing payment options.
- Fiuu checkout amount is read from the saved booking row, not trusted from the browser.
- An email address is required at the Fiuu checkout step (or can be reused from the booking form); the manual Maybank fallback does not require an email.
- The app sends the customer to Fiuu's hosted payment page using an HTML POST form.
- Fiuu displays the channels enabled for the merchant account. Customers choose their bank/e-wallet on that page.
- The booking is confirmed only after a valid signed server notification/callback is received and amount, currency, MID and order reference match the stored payment.
- The browser return is not considered proof of payment.
- If Fiuu reports a successful payment after the slot has expired or another booking now occupies the time, the booking is marked `payment_review` / `paid_review` for owner action. The webhook will not steal an occupied slot.
- Manual transfer still displays the Maybank account and requires receipt upload. A receipt changes the booking to `pending_verification`; the owner must press **Sahkan** after checking the bank transaction.

## 7. Test before going live

Use Fiuu's sandbox MID, keys and hosted-payment URL first. Test at least:

1. Successful FPX payment.
2. Failed or cancelled FPX payment.
3. Pending/deferred payment status and callback.
4. Touch 'n Go eWallet, only if the channel is enabled for the merchant account.
5. A duplicate notification (must not double-confirm or downgrade a paid payment).
6. A notification with a wrong amount, currency, MID, order ID or signature (must be rejected).
7. Payment return before notification arrives (the app must show pending, not confirmed).
8. A late success after the 15-minute hold or after another customer takes the slot (must be flagged for admin review).
9. Manual Maybank transfer and receipt verification.
10. The app on Android Chrome, iOS Safari and desktop over HTTPS.

Do not take real customer payments until Fiuu confirms the merchant's current request/response signature scheme and the complete sandbox test suite passes.

## Integration compatibility note

Fiuu's current developer documentation identifies Hosted Payment Page as an HTML form-submit integration and states that channel selection is displayed on Fiuu's hosted page. It also identifies the merchant API specification as covering Hosted Payment Page and three response endpoints. The request/response hash helper in this starter uses the established MOLPay/Fiuu `vcode` / `skey` format; because the public sample specification for those hash details is an older MOLPay document, verify the exact formulas and any Extended VCode setting against the current v13.97 merchant specification or Fiuu technical support before production. The function intentionally refuses to run when `FIUU_EXTENDED_VCODE=true` until that merchant-specific formula is confirmed.

## Documentation references

- [Fiuu developer documentation - Official API specifications](https://docs.fiuu.dev/reference/official-fiuu-api-specifications)
- [Fiuu official best-practices / hosted-page notes](https://github.com/FiuuPayment/Cheatsheet-BestPractices-Fiuu_API)

The request and response hash implementation is based on the established MOLPay/Fiuu `vcode` and `skey` structure. The current merchant-specific specification and any account-level options take precedence over this starter implementation.

## 8. Admin push notifications

The studio uses one WhatsApp number (`01167696395`) for customer enquiries. Admin alerts are therefore delivered through browser Web Push to the admin phone or other subscribed devices, not WhatsApp messages sent back to the same number.

Follow `PUSH-NOTIFICATION-SETUP.md` to generate VAPID keys, apply `supabase/migrations/20261030_admin_push_notifications.sql`, configure Supabase Edge Function secrets, deploy `manage-admin-push-subscription` and `notify-admin-push`, and create a Database Webhook for `public.bookings` INSERT and UPDATE.

After deployment, the owner logs in to the PWA and presses **Aktifkan notifikasi** on each device. The **Uji notifikasi** button confirms that the device can receive a push. Supabase Realtime refreshes the admin dashboard while it is open.

For customer enquiries, share the published HTTPS booking-app link in WhatsApp. Customers can then check available slots and make their own bookings in the app. Do not send the raw HTML file as an attachment. A conversational WhatsApp bot that answers availability inside the chat is a separate integration.


For the full production deployment, HTTPS hosting, admin bootstrap, customer WhatsApp link, and final acceptance checklist, follow `DEPLOYMENT-AND-LAUNCH.md`.
