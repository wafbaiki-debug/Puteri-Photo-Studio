-- Run after the Fiuu migration to verify the database-side setup.

select
  studio_name,
  bank_name,
  bank_account_name,
  bank_account_number
from public.studio_settings
where id = true;

select
  column_name,
  data_type,
  is_nullable
from information_schema.columns
where table_schema = 'public'
  and table_name = 'bookings'
  and column_name in (
    'payment_method',
    'payment_status',
    'payment_reference',
    'payment_channel'
  )
order by column_name;

select
  tablename,
  rowsecurity
from pg_tables
where schemaname = 'public'
  and tablename in ('bookings', 'fiuu_payments')
order by tablename;

select
  indexname
from pg_indexes
where schemaname = 'public'
  and tablename = 'fiuu_payments'
order by indexname;

select
  proname,
  prosecdef
from pg_proc
join pg_namespace on pg_namespace.oid = pg_proc.pronamespace
where nspname = 'public'
  and proname = 'apply_fiuu_gateway_result';
