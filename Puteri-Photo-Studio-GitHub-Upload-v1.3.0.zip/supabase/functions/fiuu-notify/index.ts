import { corsHeaders, parseFiuuPayload, processFiuuNotification, textResponse } from "../_shared/fiuu.ts";

Deno.serve(async (request: Request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return textResponse("Method not allowed", 405);
  try {
    const payload = await parseFiuuPayload(request);
    await processFiuuNotification(payload);
    return textResponse("OK", 200);
  } catch (error) {
    console.error("fiuu-notify error", error);
    return textResponse(error instanceof Error ? error.message : "Notification rejected", 400);
  }
});
