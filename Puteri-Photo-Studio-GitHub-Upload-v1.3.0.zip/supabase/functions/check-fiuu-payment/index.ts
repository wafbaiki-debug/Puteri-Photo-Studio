import { adminClient, corsHeaders, jsonResponse } from "../_shared/fiuu.ts";

Deno.serve(async (request: Request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return jsonResponse({ error: "Method not allowed." }, 405);
  try {
    const body = await request.json();
    const orderid = String(body?.orderid || "");
    const token = String(body?.token || "");
    if (!/^[A-Z0-9]{8,40}$/i.test(orderid) || !/^[a-f0-9]{40,80}$/i.test(token)) {
      return jsonResponse({ error: "Invalid payment reference." }, 400);
    }

    const supabase = adminClient();
    const { data, error } = await supabase
      .from("fiuu_payments")
      .select("orderid, return_token, status, booking_id")
      .eq("orderid", orderid)
      .eq("return_token", token)
      .maybeSingle();
    if (error) throw error;
    if (!data) return jsonResponse({ error: "Payment reference not found." }, 404);

    const { data: booking, error: bookingError } = await supabase
      .from("bookings")
      .select("booking_code, status, payment_status")
      .eq("id", data.booking_id)
      .maybeSingle();
    if (bookingError) throw bookingError;

    return jsonResponse({
      orderid: data.orderid,
      payment_status: data.status,
      booking_code: booking?.booking_code || null,
      booking_status: booking?.status || null,
      booking_payment_status: booking?.payment_status || null,
    });
  } catch (error) {
    console.error("check-fiuu-payment error", error);
    return jsonResponse({ error: error instanceof Error ? error.message : "Unable to check payment status." }, 500);
  }
});
