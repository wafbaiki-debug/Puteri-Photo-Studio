import { createClient } from "npm:@supabase/supabase-js@2";
import { md5 } from "npm:js-md5@0.7.3";

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS, GET",
};

export function adminClient() {
  const url = Deno.env.get("SUPABASE_URL");
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) throw new Error("Supabase server environment is not configured.");
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
  });
}

export function textResponse(body: string, status = 200) {
  return new Response(body, {
    status,
    headers: { ...corsHeaders, "Content-Type": "text/plain; charset=utf-8" },
  });
}

export async function parseFiuuPayload(request: Request): Promise<Record<string, string>> {
  const contentType = request.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    const value = await request.json();
    return Object.fromEntries(Object.entries(value || {}).map(([k, v]) => [k, String(v ?? "")]));
  }
  if (contentType.includes("multipart/form-data") || contentType.includes("application/x-www-form-urlencoded")) {
    const form = await request.formData();
    return Object.fromEntries(Array.from(form.entries()).map(([k, v]) => [k, String(v)]));
  }
  const raw = await request.text();
  return Object.fromEntries(new URLSearchParams(raw).entries());
}

function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export function normalizeCurrency(value: string): string {
  const currency = String(value || "").trim().toUpperCase();
  return currency === "RM" ? "MYR" : currency;
}

export function verifyFiuuSignature(payload: Record<string, string>): boolean {
  const secretKey = Deno.env.get("FIUU_SECRET_KEY") || "";
  const merchantId = Deno.env.get("FIUU_MERCHANT_ID") || "";
  const required = ["tranID", "orderid", "status", "domain", "amount", "currency", "paydate", "skey"];
  if (!secretKey || !merchantId || required.some((key) => !payload[key])) return false;
  if (payload.domain !== merchantId) return false;

  // Fiuu/MOLPay merchant response signature: MD5(paydate + domain + MD5(tranID + orderid + status + domain + amount + currency) + appcode + secret key).
  const firstHash = md5(
    payload.tranID + payload.orderid + payload.status + payload.domain + payload.amount + payload.currency,
  );
  const expected = md5(payload.paydate + payload.domain + firstHash + (payload.appcode || "") + secretKey);
  return constantTimeEqual(expected.toLowerCase(), payload.skey.toLowerCase());
}

export async function processFiuuNotification(payload: Record<string, string>) {
  if (!verifyFiuuSignature(payload)) throw new Error("Invalid Fiuu notification signature or merchant domain.");

  const supabase = adminClient();
  const { data: payment, error: paymentLookupError } = await supabase
    .from("fiuu_payments")
    .select("id, booking_id, amount, currency, orderid")
    .eq("orderid", payload.orderid)
    .maybeSingle();

  if (paymentLookupError) throw paymentLookupError;
  if (!payment) throw new Error("Fiuu order reference was not found.");

  const receivedAmount = Number(payload.amount);
  const expectedAmount = Number(payment.amount);
  if (!Number.isFinite(receivedAmount) || Math.round(receivedAmount * 100) !== Math.round(expectedAmount * 100)) {
    throw new Error("Fiuu notification amount does not match the booking amount.");
  }
  if (normalizeCurrency(payload.currency) !== normalizeCurrency(payment.currency)) {
    throw new Error("Fiuu notification currency does not match the booking currency.");
  }

  // The database RPC serializes callbacks per payment and booking, preventing
  // duplicate notifications or parallel attempts from confirming the same slot twice.
  const { data: result, error: applyError } = await supabase.rpc("apply_fiuu_gateway_result", {
    p_orderid: payload.orderid,
    p_txn_id: payload.tranID || null,
    p_gateway_status: payload.status,
    p_gateway_channel: payload.channel || null,
    p_gateway_paydate: payload.paydate || null,
    p_appcode: payload.appcode || null,
  });
  if (applyError) throw applyError;
  return { duplicate: false, status: String(result || "unknown") };
}
