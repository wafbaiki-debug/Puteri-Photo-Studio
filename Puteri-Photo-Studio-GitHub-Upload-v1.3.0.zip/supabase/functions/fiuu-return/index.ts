import { adminClient, corsHeaders, parseFiuuPayload, textResponse, verifyFiuuSignature } from "../_shared/fiuu.ts";

Deno.serve(async (request: Request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST" && request.method !== "GET") return textResponse("Method not allowed", 405);
  const publicAppUrl = Deno.env.get("PUBLIC_APP_URL") || "";
  if (!publicAppUrl.startsWith("https://")) return textResponse("Application return URL is not configured.", 503);

  try {
    const destination = new URL(publicAppUrl);

    // A GET is the hosted-page cancel route. It is not payment evidence and receives no status token.
    if (request.method === "GET") {
      destination.searchParams.set("payment_cancelled", "1");
      return new Response(null, { status: 303, headers: { ...corsHeaders, Location: destination.toString() } });
    }

    const payload = await parseFiuuPayload(request);
    if (!verifyFiuuSignature(payload)) return textResponse("Invalid Fiuu return signature.", 400);
    const orderid = String(payload.orderid || "");
    if (!/^[A-Z0-9]{8,40}$/i.test(orderid)) return textResponse("Missing or invalid payment return reference.", 400);

    // This endpoint only routes the browser back to the app. It never confirms payment.
    const supabase = adminClient();
    const { data: payment, error } = await supabase
      .from("fiuu_payments")
      .select("return_token")
      .eq("orderid", orderid)
      .maybeSingle();
    if (error) throw error;
    if (!payment) return textResponse("Payment reference not found.", 404);

    destination.searchParams.set("payment_return", "1");
    destination.searchParams.set("orderid", orderid);
    destination.searchParams.set("token", payment.return_token);
    return new Response(null, { status: 303, headers: { ...corsHeaders, Location: destination.toString() } });
  } catch (error) {
    console.error("fiuu-return error", error);
    return textResponse(error instanceof Error ? error.message : "Unable to return to the booking app.", 500);
  }
});
