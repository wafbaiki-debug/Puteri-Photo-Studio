import { adminClient, corsHeaders, jsonResponse } from "../_shared/fiuu.ts";
import { md5 } from "npm:js-md5@0.7.3";

Deno.serve(async (request: Request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return jsonResponse({ error: "Method not allowed." }, 405);

  try {
    const merchantId = Deno.env.get("FIUU_MERCHANT_ID") || "";
    const verifyKey = Deno.env.get("FIUU_VERIFY_KEY") || "";
    const secretKey = Deno.env.get("FIUU_SECRET_KEY") || "";
    const paymentUrlTemplate = Deno.env.get("FIUU_PAYMENT_URL") || "";
    const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
    const publicAppUrl = Deno.env.get("PUBLIC_APP_URL") || "";

    if (!merchantId || !verifyKey || !secretKey || !paymentUrlTemplate || !supabaseUrl || !publicAppUrl) {
      return jsonResponse({ error: "Fiuu or application server secrets are incomplete. Contact the studio administrator." }, 503);
    }
    if (Deno.env.get("FIUU_EXTENDED_VCODE") === "true") {
      return jsonResponse({ error: "Extended vcode is enabled. Confirm the exact currency-hash formula with Fiuu support before enabling checkout." }, 503);
    }

    const body = await request.json();
    const bookingId = String(body?.booking_id || "");
    const bookingCode = String(body?.booking_code || "");
    const suppliedEmail = String(body?.bill_email || "").trim();
    if (!/^[0-9a-f-]{36}$/i.test(bookingId) || !bookingCode) {
      return jsonResponse({ error: "Invalid booking reference." }, 400);
    }

    const supabase = adminClient();
    const { data: booking, error: bookingError } = await supabase
      .from("bookings")
      .select("id, booking_code, customer_name, customer_phone, customer_email, package_name, amount, status, hold_expires_at")
      .eq("id", bookingId)
      .eq("booking_code", bookingCode)
      .maybeSingle();

    if (bookingError) throw bookingError;
    if (!booking) return jsonResponse({ error: "Booking not found." }, 404);
    if (booking.status !== "awaiting_payment" || !booking.hold_expires_at || new Date(booking.hold_expires_at).getTime() <= Date.now()) {
      return jsonResponse({ error: "The 15-minute booking hold has expired. Please create a new booking." }, 409);
    }

    const billEmail = String(booking.customer_email || suppliedEmail).trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(billEmail)) {
      return jsonResponse({ error: "Please provide a valid email address for the Fiuu checkout." }, 400);
    }

    const attemptsSince = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    const { count: attemptCount, error: attemptError } = await supabase
      .from("fiuu_payments")
      .select("id", { count: "exact", head: true })
      .eq("booking_id", booking.id)
      .gte("created_at", attemptsSince);
    if (attemptError) throw attemptError;
    if ((attemptCount || 0) >= 3) return jsonResponse({ error: "Too many online payment attempts for this booking. Please contact the studio or use manual Maybank transfer." }, 429);

    const amount = Number(booking.amount).toFixed(2);
    const orderid = `PPS${String(booking.booking_code).replace(/[^A-Z0-9]/gi, "")}${Date.now().toString(36).toUpperCase()}`;
    const returnToken = crypto.randomUUID().replaceAll("-", "") + crypto.randomUUID().replaceAll("-", "");
    const vcode = md5(amount + merchantId + orderid + verifyKey);

    const base = supabaseUrl.replace(/\/$/, "");
    const returnUrl = `${base}/functions/v1/fiuu-return`;
    const paymentUrl = paymentUrlTemplate.replace("{merchant_id}", merchantId);
    if (!paymentUrl.startsWith("https://")) return jsonResponse({ error: "FIUU_PAYMENT_URL must be an HTTPS hosted payment URL supplied by Fiuu." }, 503);

    const fields: Record<string, string> = {
      amount,
      orderid,
      bill_name: String(booking.customer_name || "Guest").slice(0, 100),
      bill_email: billEmail.slice(0, 128),
      bill_mobile: String(booking.customer_phone || "").replace(/[^0-9]/g, "").slice(0, 30),
      bill_desc: `Puteri Photo Studio - ${String(booking.package_name || "Photo session").slice(0, 55)}`,
      country: "MY",
      currency: "MYR",
      vcode,
      returnurl: returnUrl,
      cancelurl: `${base}/functions/v1/fiuu-return`,
      callbackurl: `${base}/functions/v1/fiuu-callback`,
    };

    const { data: paymentRow, error: insertError } = await supabase.from("fiuu_payments").insert({
      booking_id: booking.id,
      orderid,
      return_token: returnToken,
      amount,
      currency: "MYR",
      status: "initiated",
    }).select("id").single();
    if (insertError) throw insertError;

    const { data: updatedBooking, error: updateBookingError } = await supabase.from("bookings").update({
      payment_method: "fiuu",
      payment_status: "pending",
      customer_email: booking.customer_email || billEmail,
      updated_at: new Date().toISOString(),
    }).eq("id", booking.id).eq("status", "awaiting_payment")
      .gt("hold_expires_at", new Date().toISOString())
      .select("id").maybeSingle();
    if (updateBookingError || !updatedBooking) {
      await supabase.from("fiuu_payments").delete().eq("id", paymentRow.id);
      if (updateBookingError) throw updateBookingError;
      return jsonResponse({ error: "The booking hold has expired. Please create a new booking." }, 409);
    }

    return jsonResponse({ payment_url: paymentUrl, method: "POST", fields, orderid });
  } catch (error) {
    console.error("create-fiuu-payment error", error);
    return jsonResponse({ error: error instanceof Error ? error.message : "Unable to start Fiuu checkout." }, 500);
  }
});
