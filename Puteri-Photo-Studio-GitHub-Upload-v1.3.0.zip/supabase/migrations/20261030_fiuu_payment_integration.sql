-- Puteri Photo Studio: Fiuu hosted checkout + manual Maybank fallback
-- Run once in Supabase SQL Editor after the existing booking schema.
-- This migration does not contain or require any Fiuu credentials.

begin;

-- Correct the current Maybank beneficiary details.
insert into public.studio_settings (id, bank_name, bank_account_name, bank_account_number)
values (true, 'Maybank', 'Puteri Norsyahira Natasya Binti Suhami', '162786160739')
on conflict (id) do update
   set bank_name = excluded.bank_name,
       bank_account_name = excluded.bank_account_name,
       bank_account_number = excluded.bank_account_number,
       updated_at = now();

-- Track the selected payment route and its normalized status on each booking.
alter table public.bookings
  add column if not exists payment_method text not null default 'manual_transfer';

alter table public.bookings
  add column if not exists payment_status text not null default 'unpaid';

alter table public.bookings
  add column if not exists payment_reference text;

alter table public.bookings
  add column if not exists payment_channel text;

alter table public.bookings drop constraint if exists bookings_payment_method_check;
alter table public.bookings
  add constraint bookings_payment_method_check
  check (payment_method in ('manual_transfer', 'fiuu'));

alter table public.bookings drop constraint if exists bookings_payment_status_check;
alter table public.bookings
  add constraint bookings_payment_status_check
  check (payment_status in ('unpaid', 'pending', 'manual_pending', 'paid', 'failed', 'expired', 'cancelled', 'paid_review'));

alter table public.bookings drop constraint if exists bookings_status_check;
alter table public.bookings
  add constraint bookings_status_check
  check (status in ('awaiting_payment', 'pending_verification', 'confirmed', 'cancelled', 'expired', 'completed', 'payment_review'));

update public.bookings
   set payment_status = case
     when status in ('confirmed', 'completed') then 'paid'
     when status = 'pending_verification' then 'manual_pending'
     when status = 'cancelled' then 'cancelled'
     when status = 'expired' then 'expired'
     else payment_status
   end;

create index if not exists bookings_payment_method_idx on public.bookings (payment_method);
create index if not exists bookings_payment_status_idx on public.bookings (payment_status);

-- One booking can have more than one Fiuu attempt; each orderid is unique.
create table if not exists public.fiuu_payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  orderid text not null unique,
  return_token text not null unique,
  amount numeric(10,2) not null check (amount >= 0),
  currency text not null default 'MYR' check (currency = 'MYR'),
  status text not null default 'initiated'
    check (status in ('initiated', 'pending', 'paid', 'failed', 'expired', 'paid_review')),
  txn_id text,
  gateway_status text,
  gateway_channel text,
  gateway_paydate text,
  appcode text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists fiuu_payments_booking_id_idx on public.fiuu_payments (booking_id);
create index if not exists fiuu_payments_booking_created_idx on public.fiuu_payments (booking_id, created_at desc);
create index if not exists fiuu_payments_status_idx on public.fiuu_payments (status);
create unique index if not exists fiuu_payments_txn_id_unique on public.fiuu_payments (txn_id) where txn_id is not null;

alter table public.fiuu_payments enable row level security;
drop policy if exists fiuu_payments_admin_read on public.fiuu_payments;
create policy fiuu_payments_admin_read on public.fiuu_payments
  for select to authenticated using (public.is_admin());

grant select on public.fiuu_payments to authenticated;
revoke all on public.fiuu_payments from anon;

-- Expire unpaid holds. A paid booking is never expired by this function.
create or replace function public.expire_booking_holds()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_count integer;
begin
  update public.bookings
     set status = 'expired',
         payment_status = 'expired',
         hold_expires_at = null,
         updated_at = now()
   where status = 'awaiting_payment'
     and payment_status in ('unpaid', 'pending', 'failed')
     and hold_expires_at is not null
     and hold_expires_at <= now();
  get diagnostics v_count = row_count;

  update public.fiuu_payments fp
     set status = 'expired', updated_at = now()
    from public.bookings b
   where fp.booking_id = b.id
     and b.status = 'expired'
     and fp.status in ('initiated', 'pending');

  return v_count;
end;
$$;

-- Manual transfer remains available. A receipt is only pending verification,
-- never automatically treated as a paid transaction.
create or replace function public.submit_booking_receipt(p_booking_id uuid, p_receipt_path text)
returns table (booking_code text, status text, receipt_uploaded_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
begin
  perform public.expire_booking_holds();

  if p_receipt_path is null or p_receipt_path not like (p_booking_id::text || '/%') then
    raise exception 'Laluan fail resit tidak sah.' using errcode = '22023';
  end if;

  return query
    update public.bookings as b
       set status = 'pending_verification',
           payment_method = 'manual_transfer',
           payment_status = 'manual_pending',
           receipt_path = p_receipt_path,
           receipt_uploaded_at = now(),
           hold_expires_at = null,
           updated_at = now()
     where b.id = p_booking_id
       and b.status = 'awaiting_payment'
       and b.hold_expires_at > now()
    returning b.booking_code, b.status, b.receipt_uploaded_at;

  if not found then
    raise exception 'Tempoh pegangan slot telah tamat atau tempahan tidak lagi aktif.' using errcode = '55000';
  end if;
end;
$$;

create or replace function public.apply_fiuu_gateway_result(
  p_orderid text,
  p_txn_id text,
  p_gateway_status text,
  p_gateway_channel text default null,
  p_gateway_paydate text default null,
  p_appcode text default null
)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_payment public.fiuu_payments%rowtype;
  v_booking public.bookings%rowtype;
  v_next_status text;
begin
  select * into v_payment
    from public.fiuu_payments
   where orderid = p_orderid
   for update;
  if not found then
    raise exception 'Fiuu order reference was not found.' using errcode = 'P0002';
  end if;

  -- A final result for this exact attempt is idempotent.
  if v_payment.status in ('paid', 'paid_review') then
    return v_payment.status;
  end if;
  if v_payment.status = 'expired' and p_gateway_status <> '00' then
    return 'expired';
  end if;
  if v_payment.status = 'failed' and p_gateway_status = '22' then
    return 'failed';
  end if;

  select * into v_booking
    from public.bookings
   where id = v_payment.booking_id
   for update;
  if not found then
    raise exception 'Booking linked to Fiuu payment was not found.' using errcode = 'P0002';
  end if;

  if p_gateway_status = '00' then
    -- Store the transaction ID first. A unique index prevents one transaction
    -- from being applied to two different payment attempts/bookings.
    update public.fiuu_payments
       set txn_id = p_txn_id,
           gateway_status = p_gateway_status,
           gateway_channel = p_gateway_channel,
           gateway_paydate = p_gateway_paydate,
           appcode = p_appcode,
           status = 'paid',
           updated_at = now()
     where id = v_payment.id;

    if v_booking.status in ('awaiting_payment', 'expired') then
      begin
        update public.bookings
           set status = 'confirmed',
               payment_method = 'fiuu',
               payment_status = 'paid',
               payment_reference = p_txn_id,
               payment_channel = p_gateway_channel,
               confirmed_at = coalesce(confirmed_at, now()),
               hold_expires_at = null,
               updated_at = now()
         where id = v_booking.id;
        return 'paid';
      exception
        when exclusion_violation then
          update public.bookings
             set status = 'payment_review',
                 payment_method = 'fiuu',
                 payment_status = 'paid_review',
                 payment_reference = p_txn_id,
                 payment_channel = p_gateway_channel,
                 hold_expires_at = null,
                 updated_at = now()
           where id = v_booking.id;
          update public.fiuu_payments
             set status = 'paid_review', updated_at = now()
           where id = v_payment.id;
          return 'paid_review';
      end;
    elsif v_booking.status = 'confirmed' then
      -- A second successful attempt for an already-confirmed booking needs a refund/review.
      update public.bookings
         set payment_method = 'fiuu', payment_status = 'paid_review', payment_reference = p_txn_id, payment_channel = p_gateway_channel, updated_at = now()
       where id = v_booking.id;
      update public.fiuu_payments
         set status = 'paid_review', updated_at = now()
       where id = v_payment.id;
      return 'paid_review';
    elsif v_booking.status = 'pending_verification' then
      -- Preserve the manual pending hold while flagging the online payment for owner review.
      update public.bookings
         set payment_method = 'fiuu', payment_status = 'paid_review', payment_reference = p_txn_id, payment_channel = p_gateway_channel, updated_at = now()
       where id = v_booking.id;
      update public.fiuu_payments
         set status = 'paid_review', updated_at = now()
       where id = v_payment.id;
      return 'paid_review';
    else
      -- Late payment after cancellation or another exceptional state.
      update public.bookings
         set status = 'payment_review',
             payment_method = 'fiuu',
             payment_status = 'paid_review',
             payment_reference = p_txn_id,
             payment_channel = p_gateway_channel,
             hold_expires_at = null,
             updated_at = now()
       where id = v_booking.id;
      update public.fiuu_payments
         set status = 'paid_review', updated_at = now()
       where id = v_payment.id;
      return 'paid_review';
    end if;
  end if;

  v_next_status := case when p_gateway_status = '22' then 'pending' else 'failed' end;
  update public.fiuu_payments
     set txn_id = coalesce(p_txn_id, txn_id),
         gateway_status = p_gateway_status,
         gateway_channel = p_gateway_channel,
         gateway_paydate = p_gateway_paydate,
         appcode = p_appcode,
         status = v_next_status,
         updated_at = now()
   where id = v_payment.id;

  update public.bookings
     set payment_method = 'fiuu', payment_status = v_next_status, payment_reference = p_txn_id, payment_channel = p_gateway_channel, updated_at = now()
   where id = v_booking.id and status = 'awaiting_payment';

  return v_next_status;
end;
$$;

revoke all on function public.apply_fiuu_gateway_result(text, text, text, text, text, text) from public, anon, authenticated;
grant execute on function public.apply_fiuu_gateway_result(text, text, text, text, text, text) to service_role;

commit;
