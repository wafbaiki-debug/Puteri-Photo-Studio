# Puteri Photo Studio v1.7.5 - Admin Push Notifications (Manual Maybank)

Push notifications are used only to alert the admin when a customer submits a Maybank transfer receipt. An unpaid booking hold is not a valid booking and does not trigger a push notification.

## Notification rule

- No push is sent when a customer first creates a booking. That record is only a temporary 10-minute slot hold.
- A push is sent when the customer uploads a receipt and the booking changes to `pending_verification`, whether the receipt is submitted during the initial hold or later while the slot is still free.
- The notification asks the admin to check the actual Maybank transaction before confirming.
- The app does not automatically treat an uploaded receipt as payment received.
- Admin confirmation changes the booking to `confirmed`; no additional push is sent for the admin's own confirmation action.

## Requirements

- The app must be published over HTTPS.
- The existing Supabase project must contain `admin_users`, `admin_push_subscriptions`, and `admin_push_notification_log`.
- The owner must log in using the authorized account in `public.admin_users`.
- The admin must enable notifications separately on each device.
- Android: Chrome is recommended; installing the PWA is recommended.
- iPhone/iPad: Web Push requires iOS/iPadOS 16.4 or later and the PWA added to the Home Screen.
- Browser notification permission must be allowed.

## 1. Database migration

If push tables have not already been created, run this migration once in Supabase SQL Editor:

`supabase/migrations/20261030_admin_push_notifications.sql`

Do not rerun it if the tables already exist. The migration creates private push-subscription and notification-log tables with RLS enabled.

## 2. VAPID keys and Edge Function secrets

Generate a VAPID key pair locally:

```sh
npx web-push generate-vapid-keys
```

Set these values in Supabase Dashboard -> Edge Functions -> Secrets:

```sh
PUSH_VAPID_PUBLIC_KEY="YOUR_VAPID_PUBLIC_KEY"
PUSH_VAPID_PRIVATE_KEY="YOUR_VAPID_PRIVATE_KEY"
PUSH_VAPID_SUBJECT="mailto:YOUR_CONTACT_EMAIL"
PUSH_WEBHOOK_SECRET="A_LONG_RANDOM_SECRET"
```

Never put the VAPID private key, service-role key, database password, or webhook secret in browser files or GitHub.

## 3. Deploy Edge Functions

Deploy both functions from the project root:

```sh
supabase functions deploy manage-admin-push-subscription
supabase functions deploy notify-admin-push
```

`manage-admin-push-subscription` requires an authenticated admin. `notify-admin-push` is a server-to-server Database Webhook and validates the `x-webhook-secret` header.

## 4. Supabase Database Webhook

In Supabase Dashboard -> Database -> Webhooks, create or update this webhook:

- Name: `pps_admin_push_notifications`
- Table: `public.bookings`
- Event: `UPDATE` only
- Method: `POST`
- URL: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/notify-admin-push`
- Header `Content-Type`: `application/json`
- Header `x-webhook-secret`: same value as `PUSH_WEBHOOK_SECRET`

The Edge Function ignores updates other than the first transition to `pending_verification` for a manual Maybank booking with a receipt path. This includes a late receipt accepted after the database rechecks that the slot is still free. Do not configure an `INSERT` event; an unpaid hold is not a booking notification.

## 5. Enable notifications on the admin phone

1. Open the production HTTPS app on the admin phone.
2. Install the PWA / Add to Home Screen if available.
3. Log in to Admin Dashboard.
4. Press **Aktifkan notifikasi** and allow browser notifications.
5. Press **Uji notifikasi** and confirm that the device receives it.
6. Repeat on any other admin device that should receive alerts.

## 6. Acceptance tests

- Create a booking: no admin push should be sent.
- Leave the booking unpaid for 10 minutes: it expires and is not displayed in the valid-booking list.
- Upload a receipt before the initial hold expires: one admin push should say to check the Maybank funds.
- Let a hold expire, then submit a late receipt while the slot is still free: the original booking becomes `pending_verification` and one admin push is sent.
- If the slot has already been taken, the late receipt is rejected and no booking overlap is created.
- The receipt appears in the separate **Semakan bayaran manual** queue, not in **Senarai tempahan sah**.
- Admin opens the receipt, checks the actual Maybank account, and presses **Sahkan bayaran** only after the full amount has arrived.
- The booking then appears in **Senarai tempahan sah** with status `confirmed`.
- If the admin cancels the pending review, the slot is released.

## Important notes

- A receipt image is not proof that the bank transfer has settled.
- Push delivery is best-effort and depends on HTTPS, VAPID configuration, browser permission, network and OS notification settings. The Admin Dashboard remains the authoritative record.
- The 10-minute period is only the initial unpaid hold. A late receipt can be accepted if the future slot is still free. After a receipt is accepted, the slot remains blocked while the admin checks the bank and either confirms or cancels it.
