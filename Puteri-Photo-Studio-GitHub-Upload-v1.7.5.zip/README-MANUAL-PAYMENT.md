# Puteri Suhaimi Photo Studio v1.7.5 - Manual Maybank Payment

This release uses manual Maybank transfer only. Fiuu checkout is disabled.

## Customer payment flow

1. Customer selects a package, date and time and submits their details.
2. The database creates a temporary `awaiting_payment` hold for 10 minutes.
3. Customer transfers the exact full package amount to the studio's Maybank account.
4. Customer uploads the receipt. If the receipt is accepted, the booking changes to `pending_verification`; its slot stays blocked until admin confirms or cancels.
5. If the initial 10-minute hold expires before the receipt is uploaded, the original booking becomes `expired` and its slot is released.
6. If the customer has paid in full after the initial 10 minutes, they may search for the original booking by booking code or phone number and submit the receipt if the requested future slot is still free. The system checks the slot again in the database and will not create an overlap.
7. If another customer has already taken the slot, the late receipt is not accepted as a slot reservation; the customer is asked to contact the studio about the payment.

## Admin payment review

- A push notification is sent when a manual Maybank receipt is accepted, including an eligible late receipt.
- The notification asks the admin to check the actual funds in the Maybank account.
- Pending receipts appear in the separate **Semakan bayaran manual** queue.
- Admin opens the receipt and checks that the full package amount has arrived in the bank.
- Only then does admin press **Sahkan bayaran**.
- The booking changes to `confirmed` and moves into **Senarai tempahan sah**.
- If funds are not received or are insufficient, admin must not confirm; cancel the pending request to release the slot.

## 10-minute rule

- The 10-minute period is only the initial unpaid slot hold.
- If no receipt is submitted by expiry, the booking becomes `expired` and the slot is released.
- Expired bookings are not valid bookings and do not appear in the confirmed-booking list.
- A customer who paid in full after expiry can still submit the receipt against the same booking if the slot is still free and in the future.
- After a receipt is accepted, `pending_verification` has no 10-minute expiry; the slot stays blocked until admin confirms or cancels.

## Customer payment resume

Customers can find an existing booking by booking code or phone number. The original booking id is reused; the app does not create a duplicate booking. The database rechecks availability at receipt submission and the exclusion constraint prevents simultaneous overlapping bookings.

## Admin and other features

- Supabase Auth login restricted by `public.admin_users`.
- Separate receipt-review queue and confirmed-booking list.
- Admin can view private receipt files using signed URLs.
- Package management, calendar, studio/bank settings and Ramadan dates.
- Realtime dashboard refresh and Web Push notifications when server-side push setup is configured.
- Android, iPhone and iPad responsive PWA.

## Database migration

For an existing Supabase project, run `20261031_late_manual_payment_reactivation_v1_7_5.sql` once in SQL Editor. It updates the receipt submission, booking lookup and receipt-storage authorization functions. It does not delete bookings or receipt files. Do not run `schema.sql` on an existing production database.

If the 10-minute expiry cron has not yet been configured, enable `pg_cron` and run `20261031_expire_unpaid_holds_cron_v1_7_4.sql`. The expiry function only expires `awaiting_payment` unpaid holds; it does not expire `pending_verification` bookings.

## Deployment

Use the v1.7.5 GitHub/Vercel bundle. Preserve the existing Supabase database and Vercel project. Do not create a new project or run the root schema on production. Keep service-role keys, database passwords, VAPID private key and `PUSH_WEBHOOK_SECRET` in server-side secrets only.
