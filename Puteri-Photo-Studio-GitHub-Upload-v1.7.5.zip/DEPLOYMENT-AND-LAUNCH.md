# Puteri Suhaimi Photo Studio - Deployment and Launch Guide (v1.7.5)

This release continues the existing Supabase database and Vercel project. Customer checkout uses **Maybank manual transfer only**. Fiuu is not shown or called by the customer app.

## v1.7.5 payment rules

- A new booking creates a temporary 10-minute hold (`awaiting_payment`) while the customer arranges payment. It is not a valid booking and does not appear in the confirmed-booking list.
- If the customer submits a receipt within the 10-minute period, the booking changes to `pending_verification`; the 10-minute expiry no longer applies and the slot stays blocked until admin confirms or cancels it.
- If the 10-minute period expires before a receipt is submitted, the unpaid hold becomes `expired` and the slot is released.
- A customer who has already paid in full may search for the original booking by booking code or phone number and submit the receipt after the 10-minute period, but only if the requested future slot is still free. The database rechecks availability at submission time and rejects overlaps.
- A late receipt accepted by the database changes the same booking row to `pending_verification`; it does not create a duplicate booking and it does not receive a new 10-minute expiry.
- An admin push notification is sent only after a receipt is accepted (on time or late). Creating an unpaid hold does not send a push.
- Admin checks the actual Maybank transaction and presses **Sahkan bayaran** only after the full package amount has arrived. Only then does the record become `confirmed` and appear in the valid-booking list.
- If funds have not arrived or are insufficient, do not confirm. Cancel the pending review to release the slot.

## Customer and studio features

- Browse active packages and prices.
- Select a future date/time; past slots, breaks and overlapping sessions are blocked.
- Ten-minute unpaid hold and Maybank account instructions.
- Receipt upload: JPG, PNG, WEBP, HEIC, HEIF or PDF, up to 10 MB.
- Sambung Pembayaran: find an existing booking by booking code or phone; an expired booking can accept a receipt only when its future slot is still free. The original booking is reused without duplication.
- Responsive PWA for Android, iPhone and iPad.

## Admin features

- Supabase Auth login restricted by `public.admin_users`.
- Separate receipt-review queue and valid-booking list.
- Private receipt viewing through signed URLs.
- Manual confirmation only after checking actual bank credit.
- Cancel pending requests, mark confirmed sessions completed, and contact customers through WhatsApp.
- Package management, calendar, studio/bank settings and Ramadan dates.
- Realtime dashboard refresh and push alerts for receipt submission.

## Existing project: preserve the live database

Do not run the root `schema.sql` on the live database. Do not recreate the Supabase project. Run this required v1.7.5 migration once in the existing Supabase SQL Editor:

1. `20261031_late_manual_payment_reactivation_v1_7_5.sql` - updates receipt submission and storage authorization, and creates/updates `lookup_booking_for_payment(text)`. It supersedes the v1.7.3 lookup-only migration. It does not delete bookings or receipt files.

Optional migrations (run only if the feature is not already installed):

- `20261031_ios_receipt_heic_10mb.sql` - supports HEIC/HEIF and a 10 MB private receipt limit.
- `supabase/migrations/20261030_admin_push_notifications.sql` - creates admin push subscription/log tables.

For background expiry of unpaid holds, enable `pg_cron` in Supabase Database -> Extensions, then run `20261031_expire_unpaid_holds_cron_v1_7_4.sql`. If `pg_cron` is unavailable, the app's booking, availability and lookup RPCs still expire old holds before checking slot availability; the optional cron makes the database status update happen in the background every minute.

## Push notification setup

1. Set `PUSH_VAPID_PUBLIC_KEY`, `PUSH_VAPID_PRIVATE_KEY`, `PUSH_VAPID_SUBJECT` and `PUSH_WEBHOOK_SECRET` in Supabase Edge Function Secrets.
2. Deploy `manage-admin-push-subscription` and `notify-admin-push` from the `supabase/functions` folder.
3. In Supabase Database -> Webhooks, configure `public.bookings` for `UPDATE` only, pointing to `/functions/v1/notify-admin-push`.
4. Include headers `Content-Type: application/json` and `x-webhook-secret` with the same value as `PUSH_WEBHOOK_SECRET`.
5. Admin logs in on each device and presses **Aktifkan notifikasi**. Use **Uji notifikasi** to test delivery.

The function only sends a push when a manual-transfer booking first changes to `pending_verification` and has a receipt path. This includes an expired booking reactivated after the database confirms its future slot is free. No push is sent for unpaid booking creation, expiry or admin confirmation.

## Vercel environment variables

Keep the existing Production variables:

- `SUPABASE_URL` - real HTTPS Supabase project URL.
- `SUPABASE_ANON_KEY` - public anon/publishable key only.
- `VAPID_PUBLIC_KEY` - public VAPID key used by the admin PWA.

Never put the Supabase service-role key, database password, VAPID private key or `PUSH_WEBHOOK_SECRET` in Vercel browser assets or GitHub.

## Deploy v1.7.5 through GitHub

1. Extract `Puteri-Photo-Studio-v1.7.5-GitHub-Vercel-Bundle.zip`.
2. Upload/replace the files listed in `README-GITHUB-VERCEL.md` in the existing repository root on branch `main`.
3. Commit to `main` and wait for Vercel's newest deployment to show `Ready`.
4. Open the production HTTPS URL and test the payment flow before sharing it with customers.

## Acceptance tests

- Create a test booking: it is a 10-minute hold only; no admin push and no valid-booking list entry.
- Leave it unpaid past 10 minutes: the initial hold expires and the slot becomes available again. The customer may later submit a receipt against the same booking only if the slot is still free.
- Upload a receipt within 10 minutes: booking appears in the admin review queue, the slot remains blocked and admin receives a push asking to check Maybank funds.
- Let a hold expire, then submit a receipt while the slot is still free: the original booking reactivates as `pending_verification`, the slot is held and admin receives a push.
- Let a hold expire, then have another booking take the slot: late receipt submission is blocked and the customer is told to contact the studio.
- Confirm the booking is not yet in the valid-booking list.
- If the transfer is not visible in the bank, do not press **Sahkan bayaran**; cancel the pending review to release the slot.
- If the full transfer is visible, press **Sahkan bayaran**; the booking becomes `confirmed` and moves to the valid-booking list.
- Search a booking by code/phone and verify Sambung Pembayaran uses the same booking record.
- Verify no duplicate booking is created when a receipt is submitted.

## Install on Android and iPhone/iPad

- Android: open the HTTPS production URL in Chrome, open the three-dot menu, then choose **Install app** / **Add to Home screen**.
- iPhone/iPad: open the HTTPS production URL in Safari, tap **Share**, then choose **Add to Home Screen**.
- iOS/iPadOS Web Push requires 16.4+ and the PWA installed on the Home Screen.

A receipt is not proof that funds have arrived. The Admin Dashboard and actual Maybank transaction are authoritative. Push delivery is best-effort and depends on device/browser permissions and connectivity.


## v1.7.5 existing database migration

Run `20261031_late_manual_payment_reactivation_v1_7_5.sql` once in Supabase SQL Editor. It changes only the receipt, lookup and storage authorization functions; it does not recreate tables or delete bookings.
