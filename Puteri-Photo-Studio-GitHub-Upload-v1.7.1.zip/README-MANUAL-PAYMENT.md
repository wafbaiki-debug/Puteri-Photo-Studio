# Puteri Suhaimi Photo Studio v1.7.1 - Manual Maybank Payment

This source package provides the responsive customer and admin PWA. Customer checkout uses **Maybank manual transfer only**. No Fiuu merchant credentials are required.

## Customer app
- Package selection: PUTERI RM140/15 min, MARYAM RM170/30 min, PREMIUM RM330/60 min.
- Date/time selection with past-time filtering and database overlap protection.
- Ten-minute unpaid hold.
- Maybank transfer instructions and receipt upload (JPG/PNG/WEBP/HEIC/HEIF/PDF, max 10 MB).
- Booking code and WhatsApp follow-up link.

## Admin app
- Supabase Auth login plus `admin_users` allow-list.
- Forgot-password email flow and secure password update form.
- Booking list, filters/search, receipt review, confirm/cancel/complete actions.
- Package management, calendar, studio/bank settings and Ramadan dates.
- Realtime and push notification support when server-side push setup is complete.

## iOS receipt storage migration
Run `20261031_ios_receipt_heic_10mb.sql` once in Supabase SQL Editor to allow HEIC/HEIF images and increase the private `receipts` bucket limit to 10 MB. Existing receipt files and bookings are not changed.

## PWA installation
- Android: Chrome > menu > Install app / Add to Home screen.
- iOS/iPadOS: Safari > Share > Add to Home Screen.
- Customer booking and admin dashboard are in the same app. Owner taps Admin and signs in with the authorized Supabase Auth account.
- iOS/iPadOS Web Push requires version 16.4+ and the PWA installed on the Home Screen. Push notifications also require VAPID server configuration.

## Admin password recovery
On the admin login screen, select **Lupa kata laluan?** and request a recovery email. Supabase Auth must be configured to allow the redirect URL `https://puteri-photo-studio-dbdd.vercel.app/**` under Authentication > URL Configuration. The recovery email link returns to `/?admin=1&recovery=1`, where the owner can set a new password. Supabase email delivery may require custom SMTP for reliable production use.

## Deployment
Use the repository bundle v1.7.1. Vercel build variables required: `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and optionally `VAPID_PUBLIC_KEY`. The build wrapper creates `config.js` from those values. Never commit private keys.

For the existing live database, do not run `schema.sql` or old migrations again without checking whether they were already applied. The existing project has already verified the 10-minute hold and past-time validation.
