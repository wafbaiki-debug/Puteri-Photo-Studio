-- Puteri Suhaimi Photo Studio v1.7.1
-- Allow common iPhone HEIC/HEIF receipt images and increase receipt limit to 10 MB.
-- Safe to run once on the existing project; does not alter existing receipt files or bookings.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'receipts',
  'receipts',
  false,
  10485760,
  array['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif', 'application/pdf']
)
on conflict (id) do update
set public = false,
    file_size_limit = 10485760,
    allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif', 'application/pdf'];
