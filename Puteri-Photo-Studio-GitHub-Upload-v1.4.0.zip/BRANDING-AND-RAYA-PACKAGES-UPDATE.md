# Puteri Suhaimi Photo Studio – Branding & Raya Packages Update

Prepared from the owner's uploaded official logo and Raya package poster.

## Files
- `index.html` – updated header/admin login logo, add-on price information, and admin package duration support for 60 minutes.
- `logo-puteri-suhaimi.png` – optimized official logo.
- `icon-192.png`, `icon-512.png`, `apple-touch-icon.png` – PWA icon assets generated from the same official logo.
- `puteri-raya-packages-migration.sql` – database migration to allow 60-minute bookings and add/update the PUTERI, MARYAM and PREMIUM packages.

## Package prices
- PUTERI: RM140, 15 minutes, 1–5 people.
- MARYAM: RM170, 30 minutes, 6–10 people.
- PREMIUM: RM330, 60 minutes, 11–20 people.

All include unlimited shoot, two backgrounds, edited photos delivered through Telegram, and children aged two and under free.

## Add-on price display
The updated page displays the poster's add-on prices. They are informational only at this stage and are not automatically added to the booking total:
- Additional person: RM15 each (overall maximum 20 people).
- Photo frame 8×12: RM25.
- Photo frame 12×18: RM100.
- Photo frame 16×24: RM160.
- Special Raya booking surcharge: RM100 for Raya eve, first day or second day.

The exact Raya dates and a fully automatic add-on checkout calculation still need to be configured before charging these extras automatically.

## Important deployment note
The Vercel project currently builds from the ZIP source package in the GitHub repository via `build.js`. Replace the matching files inside that original source ZIP, or rebuild the source ZIP, before committing the updated source to GitHub. Do not upload this patch as a replacement for the full source ZIP by itself.
