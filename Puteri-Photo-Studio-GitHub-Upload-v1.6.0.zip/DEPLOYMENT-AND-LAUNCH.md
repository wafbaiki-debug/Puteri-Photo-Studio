# Puteri Suhaimi Photo Studio - Deployment and Launch Guide (v1.6.0)

This package updates the existing live Vercel and Supabase project. Apply the frontend deployment and the 10-minute booking-hold database migration before accepting new bookings under the revised hold duration.

## Business settings already entered

- Public studio name: Puteri Suhaimi Photo Studio
- Address: 687, Round About Kuala Besut, Kuala Besut, Terengganu
- Google Maps: https://maps.app.goo.gl/S5Wu6mxiS2L3pmWu7?g_st=ac
- Customer/admin WhatsApp: 01167696395 (Malaysia international format: 601167696395)
- Manual payment: Maybank
- Account holder: PUTERI NORSYAHIRA NATASYA BINTI SUHAMI
- Account number: 162786160739
- Ramadan hours: 09:00-12:30 and 14:00-18:00
- Normal hours: 09:00-12:00, 14:00-18:00 and 20:00-00:00 (Asia/Kuala_Lumpur)
- Fiuu Hosted Payment Page + manual Maybank fallback
- Admin notifications: Web Push to admin devices (not WhatsApp, because the studio uses one WhatsApp number only)

## Required before live launch

1. Connect the Vercel hosting account and choose a project name. Vercel can provide a temporary `*.vercel.app` HTTPS URL; a custom domain can be added later.
2. Connect the existing Supabase project (or create one). Apply the migrations in the order below.
3. Create the owner's Auth user in Supabase. Run `supabase/owner-only-admin.sql` after replacing the UUID placeholder. Do not share the owner's password in chat.
4. Confirm the existing PUTERI, MARYAM and PREMIUM package prices in Admin -> Pakej; the owner has already confirmed these records in Supabase.
5. Set the Ramadan start/end dates in Admin -> Tetapan when the official dates are announced.
6. Obtain approved Fiuu merchant credentials and confirm the exact Hosted Payment Page URL, FPX and Touch 'n Go eWallet channel availability, request/response signature settings, and endpoint registration. Never put Fiuu secret keys in the browser.
7. Generate VAPID keys and configure push secrets in Supabase.
8. Deploy Supabase Edge Functions, create the database webhook, deploy the static app to Vercel, and test end-to-end.

## Supabase database setup

For the existing Puteri Photo Studio database, run only migrations that have not already been applied, in this order:

1. `supabase/migrations/20261030_fiuu_payment_integration.sql` (if not already applied).
2. `supabase/migrations/20261030_admin_push_notifications.sql` (if not already applied).
3. `supabase/migrations/20261030_puteri_raya_packages.sql` (allows 60-minute sessions and inserts/updates PUTERI, MARYAM and PREMIUM prices; run once).
4. `supabase/migrations/20261030_operating_hours_update.sql` (updates server-side booking validation to 09:00-12:00, 14:00-18:00 and 20:00-00:00; already applied for the current project).
5. `supabase/migrations/20261030_booking_hold_10_minutes.sql` (updates the server-side unpaid booking hold to 10 minutes; run once after the operating-hours migration).
6. `supabase/owner-only-admin.sql` after replacing the UUID placeholder, only if owner access has not already been bootstrapped.
7. `supabase/verify-launch.sql` and review all results.

For a brand-new database, run the root `schema.sql`, then run the Raya package migration and operating-hours migration, followed by `20261030_booking_hold_10_minutes.sql`, owner bootstrap and verification. The root schema and current operating-hours migration already set the hold to 10 minutes; the dedicated migration is safe to run once to make the existing database match. Do not apply the existing-schema migrations blindly to a fresh database.

## Configure the browser app

Edit `config.js` (this file contains public values only):

```js
window.STUDIO_CONFIG = {
  supabaseUrl: "https://YOUR_PROJECT_REF.supabase.co",
  supabaseAnonKey: "YOUR_PUBLIC_ANON_OR_PUBLISHABLE_KEY",
  pushVapidPublicKey: "YOUR_VAPID_PUBLIC_KEY",
  demoMode: false
};
```

Never put `SUPABASE_SERVICE_ROLE_KEY`, `FIUU_SECRET_KEY`, `FIUU_VERIFY_KEY`, or `PUSH_VAPID_PRIVATE_KEY` in `config.js`.

## Supabase Edge Function secrets

Configure the following secrets in Supabase Dashboard -> Edge Functions -> Secrets:

- `FIUU_MERCHANT_ID`
- `FIUU_VERIFY_KEY`
- `FIUU_SECRET_KEY`
- `FIUU_PAYMENT_URL` (exact sandbox or production URL confirmed by Fiuu)
- `FIUU_EXTENDED_VCODE` (confirm with Fiuu; current scaffold refuses true until formula is verified)
- `PUBLIC_APP_URL` (the final HTTPS Vercel URL)
- `PUSH_VAPID_PUBLIC_KEY`
- `PUSH_VAPID_PRIVATE_KEY`
- `PUSH_VAPID_SUBJECT` (for example `mailto:owner@example.com`)
- `PUSH_WEBHOOK_SECRET` (generate a long random secret)

Supabase supplies its own URL and service-role key to Edge Functions. Do not send any secret to ChatGPT or put it in source control.

## Deploy Supabase Edge Functions

From this project folder using the Supabase CLI after login/linking the correct project:

```sh
supabase functions deploy create-fiuu-payment
supabase functions deploy fiuu-notify
supabase functions deploy fiuu-callback
supabase functions deploy fiuu-return
supabase functions deploy check-fiuu-payment
supabase functions deploy manage-admin-push-subscription
supabase functions deploy notify-admin-push
```

## Configure Supabase Database Webhook for push

Create a webhook on `public.bookings`, events `INSERT` and `UPDATE`, method `POST`, URL:

`https://YOUR_PROJECT_REF.supabase.co/functions/v1/notify-admin-push`

Headers:

- `Content-Type: application/json`
- `x-webhook-secret: same value as PUSH_WEBHOOK_SECRET`

## Deploy the customer app to Vercel

Deploy this folder as a static site. `index.html` is the entry point. `.vercelignore` keeps the Supabase backend, SQL files and internal setup documents out of the public site. `vercel.json` sets no-cache headers for the service worker and browser config so updates are not trapped by stale cache. Keep `config.js`, `sw.js`, `manifest.webmanifest`, and icon files in the same root. Do not publish Fiuu secrets or service-role keys.

After Vercel deploys, copy the actual `https://...vercel.app` URL. That is the customer link to share through WhatsApp. Do not share the local HTML file or a `sandbox:` link with customers.

## Configure Fiuu merchant endpoints

Register the deployed Supabase function endpoints in the Fiuu merchant portal:

- Return URL: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/fiuu-return`
- Notification URL: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/fiuu-notify`
- Callback URL: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/fiuu-callback`

Confirm the exact Hosted Payment Page URL and all hash/VCode settings against the merchant's current Fiuu specification before production.

## Admin activation

1. Open the deployed HTTPS app on the owner's Android phone using Chrome.
2. Install the PWA / Add to Home screen.
3. Log in with the owner Auth account.
4. Press `Aktifkan notifikasi`, grant browser permission, then press `Uji notifikasi`.
5. Add packages/prices, confirm Maybank settings, and set Ramadan dates.
6. Send a test booking from a second phone and verify that the owner receives push notification and Realtime dashboard updates.

## Acceptance tests before sharing with customers

- Public user can see packages and available slots without logging in.
- Overlapping bookings are rejected by the database.
- 10-minute unpaid hold expires and slot is released.
- Ramadan slots only run 09:00-12:30 and 14:00-18:00.
- Normal slots only run 09:00-12:00, 14:00-18:00 and 20:00-00:00. No slots are generated during 12:00-14:00 or 18:00-20:00.
- Manual Maybank transfer receipt remains pending until owner verifies the bank credit.
- Fiuu sandbox success is confirmed only after signed server notification/callback.
- Failed/cancelled Fiuu attempt does not confirm a booking.
- Late/duplicate payment is flagged for review, not double-confirmed.
- Admin push works on the owner's phone; Realtime updates while dashboard is open.
- Customer WhatsApp enquiry link opens chat to 01167696395.
- Admin can share the final HTTPS booking URL through WhatsApp.

## Current known dependencies

- The production Vercel HTTPS website is already deployed.
- `SUPABASE_URL` and `SUPABASE_ANON_KEY` are already configured in Vercel Production.
- The PUTERI, MARYAM and PREMIUM package rows are already present in Supabase.
- The new operating-hours SQL migration in this version still needs to be applied to Supabase.
- Fiuu merchant credentials/channel approvals and the end-to-end payment callback remain to be verified.
- VAPID keys and the deployed push webhook must be verified before relying on push notifications.
- Ramadan start/end dates should be set by the owner when the official dates are known.

Do not accept real customer bookings or payments until these dependencies are completed and the acceptance tests pass.
