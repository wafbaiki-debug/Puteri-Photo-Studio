-- Puteri Photo Studio booking app - Supabase/Postgres schema
-- Time zone for booking rules: Asia/Kuala_Lumpur
-- Run this file in Supabase SQL Editor as the project owner.

create extension if not exists btree_gist;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.studio_settings (
  id boolean primary key default true check (id is true),
  studio_name text not null default 'Puteri Photo Studio',
  bank_name text not null default 'Maybank',
  bank_account_name text not null default 'Puteri Norsyahira Natasya Binti Suhami',
  bank_account_number text not null default '162786160739',
  whatsapp_number text not null default '601167696395',
  normal_open_time time not null default time '09:00',
  -- Legacy compatibility field; Ramadan availability is enforced as 09:00-12:30 and 14:00-18:00.
  ramadan_open_time time not null default time '09:00',
  closing_time time not null default time '00:00',
  ramadan_start date,
  ramadan_end date,
  updated_at timestamptz not null default now(),
  constraint valid_ramadan_range check (ramadan_start is null or ramadan_end is null or ramadan_end >= ramadan_start)
);

insert into public.studio_settings (id) values (true)
on conflict (id) do nothing;

-- Apply the Puteri Photo Studio starter defaults if the row is still untouched.
update public.studio_settings
   set studio_name = case when studio_name = 'Studio Foto Anda' then 'Puteri Photo Studio' else studio_name end,
       bank_name = case when bank_name = '' then 'Maybank' else bank_name end,
       bank_account_name = case when bank_account_name = '' then 'Puteri Norsyahira Natasya Binti Suhami' else bank_account_name end,
       bank_account_number = case when bank_account_number = '' then '162786160739' else bank_account_number end,
       whatsapp_number = case when whatsapp_number = '' then '601167696395' else whatsapp_number end,
       normal_open_time = time '09:00'
 where id = true;

create table if not exists public.packages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  duration_minutes integer not null check (duration_minutes in (15, 30)),
  price numeric(10,2) not null check (price >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  booking_code text not null unique default ('PPS-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8))),
  customer_name text not null,
  customer_phone text not null,
  customer_email text,
  customer_note text,
  package_id uuid references public.packages(id) on delete set null,
  package_name text not null,
  duration_minutes integer not null check (duration_minutes in (15, 30)),
  amount numeric(10,2) not null check (amount >= 0),
  start_at timestamptz not null,
  end_at timestamptz not null,
  status text not null default 'awaiting_payment'
    check (status in ('awaiting_payment', 'pending_verification', 'confirmed', 'cancelled', 'expired', 'completed', 'payment_review')),
  payment_method text not null default 'manual_transfer' check (payment_method in ('manual_transfer', 'fiuu')),
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid', 'pending', 'manual_pending', 'paid', 'failed', 'expired', 'cancelled', 'paid_review')),
  payment_reference text,
  payment_channel text,
  hold_expires_at timestamptz,
  receipt_path text,
  receipt_uploaded_at timestamptz,
  confirmed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint valid_booking_interval check (end_at > start_at),
  constraint duration_matches_interval check (end_at = start_at + make_interval(mins => duration_minutes))
);

create table if not exists public.fiuu_payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  orderid text not null unique,
  return_token text not null unique,
  amount numeric(10,2) not null check (amount >= 0),
  currency text not null default 'MYR' check (currency = 'MYR'),
  status text not null default 'initiated'
    check (status in ('initiated', 'pending', 'paid', 'failed', 'expired', 'paid_review')),
  txn_id text,
  gateway_status text,
  gateway_channel text,
  gateway_paydate text,
  appcode text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists fiuu_payments_booking_id_idx on public.fiuu_payments (booking_id);
create index if not exists fiuu_payments_booking_created_idx on public.fiuu_payments (booking_id, created_at desc);
create index if not exists fiuu_payments_status_idx on public.fiuu_payments (status);
create unique index if not exists fiuu_payments_txn_id_unique on public.fiuu_payments (txn_id) where txn_id is not null;

create index if not exists bookings_start_at_idx on public.bookings (start_at);
create index if not exists bookings_status_idx on public.bookings (status);
create index if not exists bookings_payment_method_idx on public.bookings (payment_method);
create index if not exists bookings_payment_status_idx on public.bookings (payment_status);
create index if not exists bookings_hold_expiry_idx on public.bookings (hold_expires_at) where status = 'awaiting_payment';

-- The database itself blocks concurrent overlapping active bookings.
-- Half-open ranges [start, end) allow one session to start exactly when another ends.
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'no_overlapping_active_bookings') then
    alter table public.bookings
      add constraint no_overlapping_active_bookings
      exclude using gist (tstzrange(start_at, end_at, '[)') with &&)
      where (status in ('awaiting_payment', 'pending_verification', 'confirmed'));
  end if;
end $$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.admin_users au where au.user_id = auth.uid());
$$;

create or replace function public.expire_booking_holds()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_count integer;
begin
  update public.bookings
     set status = 'expired', payment_status = 'expired', hold_expires_at = null, updated_at = now()
   where status = 'awaiting_payment'
     and payment_status in ('unpaid', 'pending', 'failed')
     and hold_expires_at is not null
     and hold_expires_at <= now();
  get diagnostics v_count = row_count;

  update public.fiuu_payments fp
     set status = 'expired', updated_at = now()
    from public.bookings b
   where fp.booking_id = b.id
     and b.status = 'expired'
     and fp.status in ('initiated', 'pending');

  return v_count;
end;
$$;

create or replace function public.get_busy_intervals(p_date date)
returns table (start_at timestamptz, end_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
begin
  perform public.expire_booking_holds();
  return query
    select b.start_at, b.end_at
      from public.bookings b
     where (b.start_at at time zone 'Asia/Kuala_Lumpur')::date = p_date
       and b.status in ('awaiting_payment', 'pending_verification', 'confirmed')
       and (b.status <> 'awaiting_payment' or b.hold_expires_at > now())
     order by b.start_at;
end;
$$;

create or replace function public.create_booking(
  p_customer_name text,
  p_customer_phone text,
  p_customer_email text,
  p_package_id uuid,
  p_start_at timestamptz,
  p_customer_note text default null
)
returns table (
  id uuid,
  booking_code text,
  start_at timestamptz,
  end_at timestamptz,
  amount numeric,
  hold_expires_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_package public.packages%rowtype;
  v_settings public.studio_settings%rowtype;
  v_local_start timestamp without time zone;
  v_local_date date;
  v_local_time time;
  v_open_at timestamptz;
  v_morning_close_at timestamptz;
  v_afternoon_open_at timestamptz;
  v_day_close_at timestamptz;
  v_evening_open_at timestamptz;
  v_close_at timestamptz;
  v_ramadan_morning_open_at timestamptz;
  v_ramadan_morning_close_at timestamptz;
  v_ramadan_afternoon_open_at timestamptz;
  v_ramadan_afternoon_close_at timestamptz;
  v_end_at timestamptz;
  v_is_ramadan boolean;
begin
  perform public.expire_booking_holds();

  if coalesce(length(trim(p_customer_name)), 0) < 2 or length(trim(p_customer_name)) > 100 then
    raise exception 'Sila masukkan nama pelanggan yang sah.' using errcode = '22023';
  end if;
  if coalesce(length(trim(p_customer_phone)), 0) < 8 or length(trim(p_customer_phone)) > 30 then
    raise exception 'Sila masukkan nombor telefon yang sah.' using errcode = '22023';
  end if;
  if p_start_at is null or p_start_at <= now() then
    raise exception 'Masa tempahan mesti pada masa hadapan.' using errcode = '22023';
  end if;
  if p_start_at <> date_trunc('minute', p_start_at) then
    raise exception 'Masa mula mesti tepat pada minit.' using errcode = '22023';
  end if;

  select * into v_package
    from public.packages p
   where p.id = p_package_id and p.active = true;
  if not found then
    raise exception 'Pakej tidak aktif atau tidak ditemui.' using errcode = '22023';
  end if;

  select * into v_settings from public.studio_settings where id = true;
  if not found then
    raise exception 'Tetapan studio belum disediakan.' using errcode = '55000';
  end if;

  v_local_start := p_start_at at time zone 'Asia/Kuala_Lumpur';
  v_local_date := v_local_start::date;
  v_local_time := v_local_start::time;

  if extract(minute from v_local_start)::integer % 15 <> 0 or extract(second from v_local_start) <> 0 then
    raise exception 'Masa mula mestilah pada sela 15 minit.' using errcode = '22023';
  end if;

  v_is_ramadan := v_settings.ramadan_start is not null
      and v_settings.ramadan_end is not null
      and v_local_date between v_settings.ramadan_start and v_settings.ramadan_end;

  v_close_at := ((v_local_date + 1)::timestamp without time zone) at time zone 'Asia/Kuala_Lumpur';
  v_end_at := p_start_at + make_interval(mins => v_package.duration_minutes);

  if v_is_ramadan then
    v_ramadan_morning_open_at := (v_local_date + time '09:00') at time zone 'Asia/Kuala_Lumpur';
    v_ramadan_morning_close_at := (v_local_date + time '12:30') at time zone 'Asia/Kuala_Lumpur';
    v_ramadan_afternoon_open_at := (v_local_date + time '14:00') at time zone 'Asia/Kuala_Lumpur';
    v_ramadan_afternoon_close_at := (v_local_date + time '18:00') at time zone 'Asia/Kuala_Lumpur';

    if not (
      (p_start_at >= v_ramadan_morning_open_at and v_end_at <= v_ramadan_morning_close_at)
      or
      (p_start_at >= v_ramadan_afternoon_open_at and v_end_at <= v_ramadan_afternoon_close_at)
    ) then
      raise exception 'Untuk tarikh Ramadan, sesi hanya dibenarkan dari 9:00 pagi hingga 12:30 tengah hari dan 2:00 petang hingga 6:00 petang. Rehat 12:30 hingga 2:00 petang.' using errcode = '22023';
    end if;
  else
    v_open_at := (v_local_date + time '09:00') at time zone 'Asia/Kuala_Lumpur';
    v_morning_close_at := (v_local_date + time '12:00') at time zone 'Asia/Kuala_Lumpur';
    v_afternoon_open_at := (v_local_date + time '14:00') at time zone 'Asia/Kuala_Lumpur';
    v_day_close_at := (v_local_date + time '18:00') at time zone 'Asia/Kuala_Lumpur';
    v_evening_open_at := (v_local_date + time '20:00') at time zone 'Asia/Kuala_Lumpur';
    if not (
      (p_start_at >= v_open_at and v_end_at <= v_morning_close_at)
      or (p_start_at >= v_afternoon_open_at and v_end_at <= v_day_close_at)
      or (p_start_at >= v_evening_open_at and v_end_at <= v_close_at)
    ) then
      raise exception 'Waktu sesi biasa ialah 9:00 pagi–12:00 tengah hari, 2:00–6:00 petang dan 8:00 malam–12:00 tengah malam. Waktu rehat 12:00–2:00 petang dan 6:00–8:00 malam.' using errcode = '22023';
    end if;
  end if;

  return query
    insert into public.bookings as b (
      customer_name, customer_phone, customer_email, customer_note,
      package_id, package_name, duration_minutes, amount,
      start_at, end_at, status, hold_expires_at
    ) values (
      trim(p_customer_name), trim(p_customer_phone), nullif(trim(coalesce(p_customer_email, '')), ''), nullif(trim(coalesce(p_customer_note, '')), ''),
      v_package.id, v_package.name, v_package.duration_minutes, v_package.price,
      p_start_at, v_end_at, 'awaiting_payment', now() + interval '15 minutes'
    )
    returning b.id, b.booking_code, b.start_at, b.end_at, b.amount, b.hold_expires_at;
end;
$$;

create or replace function public.submit_booking_receipt(p_booking_id uuid, p_receipt_path text)
returns table (booking_code text, status text, receipt_uploaded_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
begin
  perform public.expire_booking_holds();

  if p_receipt_path is null or p_receipt_path not like (p_booking_id::text || '/%') then
    raise exception 'Laluan fail resit tidak sah.' using errcode = '22023';
  end if;

  return query
    update public.bookings as b
       set status = 'pending_verification',
           payment_method = 'manual_transfer',
           payment_status = 'manual_pending',
           receipt_path = p_receipt_path,
           receipt_uploaded_at = now(),
           hold_expires_at = null,
           updated_at = now()
     where b.id = p_booking_id
       and b.status = 'awaiting_payment'
       and b.hold_expires_at > now()
    returning b.booking_code, b.status, b.receipt_uploaded_at;

  if not found then
    raise exception 'Tempoh pegangan slot telah tamat atau tempahan tidak lagi aktif.' using errcode = '55000';
  end if;
end;
$$;

create or replace function public.apply_fiuu_gateway_result(
  p_orderid text,
  p_txn_id text,
  p_gateway_status text,
  p_gateway_channel text default null,
  p_gateway_paydate text default null,
  p_appcode text default null
)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_payment public.fiuu_payments%rowtype;
  v_booking public.bookings%rowtype;
  v_next_status text;
begin
  select * into v_payment
    from public.fiuu_payments
   where orderid = p_orderid
   for update;
  if not found then
    raise exception 'Fiuu order reference was not found.' using errcode = 'P0002';
  end if;

  -- A final result for this exact attempt is idempotent.
  if v_payment.status in ('paid', 'paid_review') then
    return v_payment.status;
  end if;
  if v_payment.status = 'expired' and p_gateway_status <> '00' then
    return 'expired';
  end if;
  if v_payment.status = 'failed' and p_gateway_status = '22' then
    return 'failed';
  end if;

  select * into v_booking
    from public.bookings
   where id = v_payment.booking_id
   for update;
  if not found then
    raise exception 'Booking linked to Fiuu payment was not found.' using errcode = 'P0002';
  end if;

  if p_gateway_status = '00' then
    -- Store the transaction ID first. A unique index prevents one transaction
    -- from being applied to two different payment attempts/bookings.
    update public.fiuu_payments
       set txn_id = p_txn_id,
           gateway_status = p_gateway_status,
           gateway_channel = p_gateway_channel,
           gateway_paydate = p_gateway_paydate,
           appcode = p_appcode,
           status = 'paid',
           updated_at = now()
     where id = v_payment.id;

    if v_booking.status in ('awaiting_payment', 'expired') then
      begin
        update public.bookings
           set status = 'confirmed',
               payment_method = 'fiuu',
               payment_status = 'paid',
               payment_reference = p_txn_id,
               payment_channel = p_gateway_channel,
               confirmed_at = coalesce(confirmed_at, now()),
               hold_expires_at = null,
               updated_at = now()
         where id = v_booking.id;
        return 'paid';
      exception
        when exclusion_violation then
          update public.bookings
             set status = 'payment_review',
                 payment_method = 'fiuu',
                 payment_status = 'paid_review',
                 payment_reference = p_txn_id,
                 payment_channel = p_gateway_channel,
                 hold_expires_at = null,
                 updated_at = now()
           where id = v_booking.id;
          update public.fiuu_payments
             set status = 'paid_review', updated_at = now()
           where id = v_payment.id;
          return 'paid_review';
      end;
    elsif v_booking.status = 'confirmed' then
      -- A second successful attempt for an already-confirmed booking needs a refund/review.
      update public.bookings
         set payment_method = 'fiuu', payment_status = 'paid_review', payment_reference = p_txn_id, payment_channel = p_gateway_channel, updated_at = now()
       where id = v_booking.id;
      update public.fiuu_payments
         set status = 'paid_review', updated_at = now()
       where id = v_payment.id;
      return 'paid_review';
    elsif v_booking.status = 'pending_verification' then
      -- Preserve the manual pending hold while flagging the online payment for owner review.
      update public.bookings
         set payment_method = 'fiuu', payment_status = 'paid_review', payment_reference = p_txn_id, payment_channel = p_gateway_channel, updated_at = now()
       where id = v_booking.id;
      update public.fiuu_payments
         set status = 'paid_review', updated_at = now()
       where id = v_payment.id;
      return 'paid_review';
    else
      -- Late payment after cancellation or another exceptional state.
      update public.bookings
         set status = 'payment_review',
             payment_method = 'fiuu',
             payment_status = 'paid_review',
             payment_reference = p_txn_id,
             payment_channel = p_gateway_channel,
             hold_expires_at = null,
             updated_at = now()
       where id = v_booking.id;
      update public.fiuu_payments
         set status = 'paid_review', updated_at = now()
       where id = v_payment.id;
      return 'paid_review';
    end if;
  end if;

  v_next_status := case when p_gateway_status = '22' then 'pending' else 'failed' end;
  update public.fiuu_payments
     set txn_id = coalesce(p_txn_id, txn_id),
         gateway_status = p_gateway_status,
         gateway_channel = p_gateway_channel,
         gateway_paydate = p_gateway_paydate,
         appcode = p_appcode,
         status = v_next_status,
         updated_at = now()
   where id = v_payment.id;

  update public.bookings
     set payment_method = 'fiuu', payment_status = v_next_status, payment_reference = p_txn_id, payment_channel = p_gateway_channel, updated_at = now()
   where id = v_booking.id and status = 'awaiting_payment';

  return v_next_status;
end;
$$;

revoke all on function public.apply_fiuu_gateway_result(text, text, text, text, text, text) from public, anon, authenticated;
grant execute on function public.apply_fiuu_gateway_result(text, text, text, text, text, text) to service_role;

create or replace function public.can_upload_receipt(p_booking_id_text text)
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_booking_id uuid;
begin
  if p_booking_id_text is null or p_booking_id_text !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
    return false;
  end if;
  v_booking_id := p_booking_id_text::uuid;
  return exists (
    select 1 from public.bookings b
     where b.id = v_booking_id
       and b.status = 'awaiting_payment'
       and b.hold_expires_at > now()
  );
end;
$$;

alter table public.admin_users enable row level security;
alter table public.studio_settings enable row level security;
alter table public.packages enable row level security;
alter table public.bookings enable row level security;
alter table public.fiuu_payments enable row level security;

drop policy if exists admin_users_select_self on public.admin_users;
create policy admin_users_select_self on public.admin_users
  for select to authenticated using (user_id = auth.uid());

drop policy if exists settings_public_read on public.studio_settings;
create policy settings_public_read on public.studio_settings
  for select to anon, authenticated using (true);
drop policy if exists settings_admin_update on public.studio_settings;
create policy settings_admin_update on public.studio_settings
  for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists packages_public_read on public.packages;
create policy packages_public_read on public.packages
  for select to anon, authenticated using (active = true or public.is_admin());
drop policy if exists packages_admin_insert on public.packages;
create policy packages_admin_insert on public.packages
  for insert to authenticated with check (public.is_admin());
drop policy if exists packages_admin_update on public.packages;
create policy packages_admin_update on public.packages
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists packages_admin_delete on public.packages;
create policy packages_admin_delete on public.packages
  for delete to authenticated using (public.is_admin());

-- Public customers must use the RPCs; direct booking reads/inserts are blocked.
drop policy if exists bookings_admin_read on public.bookings;
create policy bookings_admin_read on public.bookings
  for select to authenticated using (public.is_admin());
drop policy if exists bookings_admin_update on public.bookings;
create policy bookings_admin_update on public.bookings
  for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists fiuu_payments_admin_read on public.fiuu_payments;
create policy fiuu_payments_admin_read on public.fiuu_payments
  for select to authenticated using (public.is_admin());

grant select on public.fiuu_payments to authenticated;
revoke all on public.fiuu_payments from anon;

grant execute on function public.is_admin() to anon, authenticated;
grant execute on function public.expire_booking_holds() to service_role;
grant execute on function public.get_busy_intervals(date) to anon, authenticated;
grant execute on function public.create_booking(text, text, text, uuid, timestamptz, text) to anon, authenticated;
grant execute on function public.submit_booking_receipt(uuid, text) to anon, authenticated;
grant execute on function public.can_upload_receipt(text) to anon, authenticated;

-- Private storage bucket for bank transfer receipts.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('receipts', 'receipts', false, 5242880, array['image/jpeg', 'image/png', 'image/webp', 'application/pdf'])
on conflict (id) do update set public = false, file_size_limit = 5242880, allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

drop policy if exists receipt_customer_upload_during_hold on storage.objects;
create policy receipt_customer_upload_during_hold on storage.objects
  for insert to anon, authenticated
  with check (bucket_id = 'receipts' and public.can_upload_receipt((storage.foldername(name))[1]));

drop policy if exists receipt_admin_read on storage.objects;
create policy receipt_admin_read on storage.objects
  for select to authenticated
  using (bucket_id = 'receipts' and public.is_admin());

drop policy if exists receipt_admin_delete on storage.objects;
create policy receipt_admin_delete on storage.objects
  for delete to authenticated
  using (bucket_id = 'receipts' and public.is_admin());

-- Automatic release of unpaid holds. Supabase supports pg_cron on eligible projects.
-- If this extension is available, uncomment/run the next two statements once:
-- create extension if not exists pg_cron with schema pg_catalog;
-- select cron.schedule('expire-booking-holds', '* * * * *', $$select public.expire_booking_holds();$$);
-- The booking/availability RPCs also expire old holds before checking availability.

-- Enable realtime updates for the owner dashboard when Supabase Realtime is available.
-- RLS still limits booking row visibility to the authenticated owner/admin.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'bookings') then
      alter publication supabase_realtime add table public.bookings;
    end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'packages') then
      alter publication supabase_realtime add table public.packages;
    end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'studio_settings') then
      alter publication supabase_realtime add table public.studio_settings;
    end if;
  end if;
exception
  when duplicate_object then null;
end $$;

create table if not exists public.admin_push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth_key text not null,
  subscription jsonb not null,
  user_agent text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

create index if not exists admin_push_subscriptions_user_idx
  on public.admin_push_subscriptions (user_id, last_seen_at desc);

alter table public.admin_push_subscriptions enable row level security;
revoke all on public.admin_push_subscriptions from anon, authenticated;
grant all on public.admin_push_subscriptions to service_role;

create table if not exists public.admin_push_notification_log (
  id uuid primary key default gen_random_uuid(),
  event_key text not null unique,
  booking_id uuid references public.bookings(id) on delete set null,
  event_type text not null check (event_type in (
    'new_booking', 'manual_receipt_received', 'payment_confirmed',
    'payment_review', 'booking_cancelled', 'payment_issue'
  )),
  status text not null default 'processing'
    check (status in ('processing', 'sent', 'partial', 'failed', 'no_subscribers')),
  sent_count integer not null default 0,
  failed_count integer not null default 0,
  attempts integer not null default 1 check (attempts > 0),
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists admin_push_notification_log_booking_idx
  on public.admin_push_notification_log (booking_id, created_at desc);
create index if not exists admin_push_notification_log_status_idx
  on public.admin_push_notification_log (status, created_at desc);

alter table public.admin_push_notification_log enable row level security;
revoke all on public.admin_push_notification_log from anon, authenticated;
grant all on public.admin_push_notification_log to service_role;

-- Ensure bookings are available to the authenticated admin Realtime dashboard.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'bookings'
    ) then
      alter publication supabase_realtime add table public.bookings;
    end if;
  end if;
exception when duplicate_object then null;
end $$;
