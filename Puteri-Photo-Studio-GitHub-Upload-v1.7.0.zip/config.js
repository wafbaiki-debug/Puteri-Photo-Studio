// Public browser configuration for Puteri Photo Studio.
// Replace placeholders after the Supabase project and VAPID keys are ready.
// Never put Supabase service-role keys, Fiuu Secret Key, or VAPID private keys here.
window.STUDIO_CONFIG = {
  supabaseUrl: "https://YOUR_PROJECT_REF.supabase.co",
  supabaseAnonKey: "YOUR_PUBLIC_SUPABASE_ANON_OR_PUBLISHABLE_KEY",
  pushVapidPublicKey: "YOUR_VAPID_PUBLIC_KEY",
  demoMode: true
};
