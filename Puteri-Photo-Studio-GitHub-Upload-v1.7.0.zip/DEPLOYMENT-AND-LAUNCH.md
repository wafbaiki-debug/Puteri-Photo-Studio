# Puteri Suhaimi Photo Studio - Deployment and Launch Guide (v1.7.0)

This release keeps the existing Supabase database and Vercel project. It changes the customer checkout to **Maybank manual transfer only**. Fiuu is not shown or called by the customer app. No Fiuu Merchant ID is required for this release.

## Customer features

- Browse active photography packages and prices.
- Select a future date and an available 15-minute interval.
- Past dates/times, breaks and occupied/overlapping sessions are blocked.
- Submit customer name, phone, optional email and note.
- Reserve the selected slot for 10 minutes.
- Display the studio's Maybank account and exact amount.
- Upload JPG, PNG, WEBP or PDF receipt (maximum 5 MB).
- Receive a booking code and WhatsApp message link after receipt upload.

## Admin features

- Secure Supabase Auth login restricted by `public.admin_users`.
- Booking dashboard, date/status filters and customer search.
- Open private receipt files through signed URLs.
- Confirm payment only after checking the actual bank transaction.
- Cancel bookings, mark sessions completed and contact customers through WhatsApp.
- Add/edit/activate/deactivate packages and prices.
- View daily calendar and occupied slots.
- Edit studio and Maybank details, WhatsApp contact and Ramadan date range.
- Optional realtime refresh and Web Push notifications when their Supabase setup is complete.

## Confirmed studio settings

- Studio: Puteri Suhaimi Photo Studio
- Address: 687, Round About Kuala Besut, Kuala Besut, Terengganu
- WhatsApp: 601167696395
- Bank: Maybank
- Account holder: PUTERI NORSYAHIRA NATASYA BINTI SUHAMI
- Account number: 162786160739
- PUTERI: RM140, 15 minutes, 1-5 people
- MARYAM: RM170, 30 minutes, 6-10 people
- PREMIUM: RM330, 60 minutes, 11-20 people
- Normal hours: 09:00-12:00, 14:00-18:00, 20:00-00:00
- Breaks: 12:00-14:00 and 18:00-20:00
- Ramadan hours: 09:00-12:30 and 14:00-18:00 when configured by admin
- Unpaid booking hold: 10 minutes

## Existing project: do not recreate the database

The current Supabase project has already been configured and the 10-minute/past-time checks were verified. Do not rerun the root `schema.sql` on the live database. Do not rerun old migrations blindly.

If setting up a genuinely new Supabase project, use `schema.sql` once, then apply the package and operating-hours migrations as documented in the SQL files. For the existing project, only apply a migration when a verified missing feature requires it.

## Vercel environment variables

The build wrapper expects these existing Vercel Project Environment Variables:

- `SUPABASE_URL` - the HTTPS Supabase project URL.
- `SUPABASE_ANON_KEY` - the public anon/publishable key only.
- `VAPID_PUBLIC_KEY` - only needed for admin web push.

The build generates `config.js` inside `dist/`. Do not add service-role keys, database passwords, Fiuu secret keys or VAPID private keys to the browser bundle or GitHub.

## Deploy v1.7.0 through GitHub

Upload/replace these five files in the repository root on branch `main`:

1. `Puteri-Photo-Studio-GitHub-Upload-v1.7.0.zip`
2. `build.js`
3. `package.json`
4. `vercel.json`
5. `README-GITHUB-VERCEL.md`

Commit directly to `main`. Vercel should start a new deployment automatically. Wait for the newest deployment to show `Ready` before testing.

## Install on Android and iPhone/iPad

This is a responsive Progressive Web App (PWA), not a native App Store/Play Store binary.

- Android: open the HTTPS production URL in Chrome, open the three-dot menu, then choose **Install app** or **Add to Home screen**.
- iPhone/iPad: open the HTTPS production URL in Safari, tap **Share**, then choose **Add to Home Screen**.
- Open the installed app icon. Customer booking works on both platforms; admin can also sign in from the installed app.
- Internet access is required for booking, receipt upload, Supabase and admin updates. The cached app shell does not make payments or bookings work offline.

## Manual payment workflow

1. Customer chooses package/date/time and submits details.
2. Database creates an `awaiting_payment` booking with a 10-minute hold.
3. Customer transfers the exact amount to the Maybank account shown.
4. Customer uploads the transaction receipt before the hold expires.
5. Receipt submission changes the booking to `pending_verification` and keeps the interval blocked while admin reviews it.
6. Admin checks the actual bank transaction, opens the receipt, then presses **Sahkan**.
7. The booking becomes `confirmed`; only then is the payment counted as received.

A receipt upload is not proof that funds have arrived. Admin must verify the bank transaction before confirming.

## Fiuu status

Fiuu checkout is disabled in the v1.7.0 customer interface. The existing `create-fiuu-payment` Edge Function and any unused Fiuu secrets may be left dormant; this app release does not invoke them. Do not add or expose Fiuu credentials for the manual-only workflow.
