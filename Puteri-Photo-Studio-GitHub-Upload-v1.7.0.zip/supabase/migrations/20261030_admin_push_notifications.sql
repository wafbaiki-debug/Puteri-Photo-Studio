-- Puteri Photo Studio: browser push notifications for the studio admin.
-- Run after 20261030_fiuu_payment_integration.sql.
-- No WhatsApp sender number is required. The admin device subscribes through the PWA.

begin;

create table if not exists public.admin_push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth_key text not null,
  subscription jsonb not null,
  user_agent text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

create index if not exists admin_push_subscriptions_user_idx
  on public.admin_push_subscriptions (user_id, last_seen_at desc);

alter table public.admin_push_subscriptions enable row level security;
revoke all on public.admin_push_subscriptions from anon, authenticated;
grant all on public.admin_push_subscriptions to service_role;

create table if not exists public.admin_push_notification_log (
  id uuid primary key default gen_random_uuid(),
  event_key text not null unique,
  booking_id uuid references public.bookings(id) on delete set null,
  event_type text not null check (event_type in (
    'new_booking', 'manual_receipt_received', 'payment_confirmed',
    'payment_review', 'booking_cancelled', 'payment_issue'
  )),
  status text not null default 'processing'
    check (status in ('processing', 'sent', 'partial', 'failed', 'no_subscribers')),
  sent_count integer not null default 0,
  failed_count integer not null default 0,
  attempts integer not null default 1 check (attempts > 0),
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists admin_push_notification_log_booking_idx
  on public.admin_push_notification_log (booking_id, created_at desc);
create index if not exists admin_push_notification_log_status_idx
  on public.admin_push_notification_log (status, created_at desc);

alter table public.admin_push_notification_log enable row level security;
revoke all on public.admin_push_notification_log from anon, authenticated;
grant all on public.admin_push_notification_log to service_role;

-- Ensure bookings are available to the authenticated admin Realtime dashboard.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'bookings'
    ) then
      alter publication supabase_realtime add table public.bookings;
    end if;
  end if;
exception when duplicate_object then null;
end $$;

commit;
