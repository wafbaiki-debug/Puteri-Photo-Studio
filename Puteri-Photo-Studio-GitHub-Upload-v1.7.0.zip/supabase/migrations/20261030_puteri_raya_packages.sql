-- Puteri Suhaimi Photo Studio - official Raya package prices
-- Run once in Supabase SQL Editor after the existing v1.3.0 schema/migrations.
-- This migration allows the Premium 60-minute package and seeds the three packages.

begin;

-- The existing v1.3.0 schema only allowed 15/30 minutes.
-- Premium is 60 minutes, so both package and booking constraints must allow it.
alter table public.packages
  drop constraint if exists packages_duration_minutes_check;
alter table public.packages
  add constraint packages_duration_minutes_check
  check (duration_minutes in (15, 30, 60));

alter table public.bookings
  drop constraint if exists bookings_duration_minutes_check;
alter table public.bookings
  add constraint bookings_duration_minutes_check
  check (duration_minutes in (15, 30, 60));

-- Deactivate the two generic starter examples if they exist.
update public.packages
   set active = false,
       updated_at = now()
 where lower(name) in ('pakej mini portrait', 'pakej sesi studio');

-- Update existing matching Raya packages without creating duplicates.
update public.packages
   set description = '1–5 orang. 15 minit. Unlimited shoot. 2 background. Semua gambar diedit dan dihantar melalui Telegram. Kanak-kanak berumur 2 tahun ke bawah percuma.',
       duration_minutes = 15,
       price = 140.00,
       active = true,
       updated_at = now()
 where lower(name) = 'puteri';

update public.packages
   set description = '6–10 orang. 30 minit. Unlimited shoot. 2 background. Semua gambar diedit dan dihantar melalui Telegram. Kanak-kanak berumur 2 tahun ke bawah percuma.',
       duration_minutes = 30,
       price = 170.00,
       active = true,
       updated_at = now()
 where lower(name) = 'maryam';

update public.packages
   set description = '11–20 orang. 60 minit. Unlimited shoot. 2 background. Semua gambar diedit dan dihantar melalui Telegram. Kanak-kanak berumur 2 tahun ke bawah percuma.',
       duration_minutes = 60,
       price = 330.00,
       active = true,
       updated_at = now()
 where lower(name) = 'premium';

-- Insert only packages that do not already exist.
insert into public.packages (name, description, duration_minutes, price, active)
select 'PUTERI',
       '1–5 orang. 15 minit. Unlimited shoot. 2 background. Semua gambar diedit dan dihantar melalui Telegram. Kanak-kanak berumur 2 tahun ke bawah percuma.',
       15, 140.00, true
where not exists (select 1 from public.packages where lower(name) = 'puteri');

insert into public.packages (name, description, duration_minutes, price, active)
select 'MARYAM',
       '6–10 orang. 30 minit. Unlimited shoot. 2 background. Semua gambar diedit dan dihantar melalui Telegram. Kanak-kanak berumur 2 tahun ke bawah percuma.',
       30, 170.00, true
where not exists (select 1 from public.packages where lower(name) = 'maryam');

insert into public.packages (name, description, duration_minutes, price, active)
select 'PREMIUM',
       '11–20 orang. 60 minit. Unlimited shoot. 2 background. Semua gambar diedit dan dihantar melalui Telegram. Kanak-kanak berumur 2 tahun ke bawah percuma.',
       60, 330.00, true
where not exists (select 1 from public.packages where lower(name) = 'premium');

commit;

-- Verify the result.
select name, duration_minutes, price, active, description
from public.packages
where lower(name) in ('puteri', 'maryam', 'premium')
order by price;
