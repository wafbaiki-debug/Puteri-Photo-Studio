import { createClient } from "npm:@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, "content-type": "application/json; charset=utf-8" },
});

function requiredEnv(name: string): string {
  const value = Deno.env.get(name)?.trim();
  if (!value) throw new Error(`Missing Edge Function secret: ${name}`);
  return value;
}

function configurePush() {
  webpush.setVapidDetails(
    requiredEnv("PUSH_VAPID_SUBJECT"),
    requiredEnv("PUSH_VAPID_PUBLIC_KEY"),
    requiredEnv("PUSH_VAPID_PRIVATE_KEY"),
  );
}

Deno.serve(async (request: Request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const authorization = request.headers.get("Authorization") || "";
    if (!authorization.startsWith("Bearer ")) return json({ error: "Authentication required" }, 401);

    const supabaseUrl = requiredEnv("SUPABASE_URL");
    const anonKey = requiredEnv("SUPABASE_ANON_KEY");
    const serviceRoleKey = requiredEnv("SUPABASE_SERVICE_ROLE_KEY");
    const authClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authorization } },
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data: userResult, error: userError } = await authClient.auth.getUser();
    if (userError || !userResult.user) return json({ error: "Invalid admin session" }, 401);

    const db = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false } });
    const { data: adminRecord, error: adminError } = await db.from("admin_users")
      .select("user_id").eq("user_id", userResult.user.id).maybeSingle();
    if (adminError) throw adminError;
    if (!adminRecord) return json({ error: "Admin access required" }, 403);

    const payload = await request.json();
    const action = String(payload?.action || "");

    if (action === "subscribe") {
      const subscription = payload?.subscription;
      const endpoint = String(subscription?.endpoint || "");
      const p256dh = String(subscription?.keys?.p256dh || "");
      const authKey = String(subscription?.keys?.auth || "");
      let endpointUrl: URL;
      try { endpointUrl = new URL(endpoint); }
      catch (_) { return json({ error: "Push endpoint is invalid" }, 400); }
      if (endpointUrl.protocol !== "https:" || endpoint.length > 4096 || !p256dh || !authKey) {
        return json({ error: "Push subscription is incomplete or invalid" }, 400);
      }
      const { error } = await db.from("admin_push_subscriptions").upsert({
        user_id: userResult.user.id,
        endpoint,
        p256dh,
        auth_key: authKey,
        subscription,
        user_agent: request.headers.get("user-agent")?.slice(0, 500) || null,
        updated_at: new Date().toISOString(),
        last_seen_at: new Date().toISOString(),
      }, { onConflict: "endpoint" });
      if (error) throw error;
      return json({ ok: true, subscribed: true });
    }

    if (action === "unsubscribe") {
      const endpoint = String(payload?.endpoint || "");
      if (!endpoint) return json({ error: "Endpoint is required" }, 400);
      const { error } = await db.from("admin_push_subscriptions").delete()
        .eq("user_id", userResult.user.id).eq("endpoint", endpoint);
      if (error) throw error;
      return json({ ok: true, subscribed: false });
    }

    if (action === "test") {
      configurePush();
      const { data: subscriptions, error } = await db.from("admin_push_subscriptions")
        .select("id,endpoint,subscription").eq("user_id", userResult.user.id);
      if (error) throw error;
      if (!subscriptions?.length) return json({ sent: 0, message: "Tiada peranti berdaftar." });
      const results = await Promise.all(subscriptions.map(async (row) => {
        try {
          await webpush.sendNotification(row.subscription, JSON.stringify({
            title: "Puteri Photo Studio",
            body: "Ujian berjaya. Telefon admin sedia menerima notifikasi tempahan.",
            tag: "puteri-admin-push-test",
            url: "./index.html?admin=1",
          }), { TTL: 300, urgency: "normal" });
          return { ok: true };
        } catch (error) {
          const statusCode = Number((error as { statusCode?: number })?.statusCode || 0);
          if (statusCode === 404 || statusCode === 410) {
            await db.from("admin_push_subscriptions").delete().eq("id", row.id);
          }
          return { ok: false, message: error instanceof Error ? error.message : "Push failed" };
        }
      }));
      const sent = results.filter((item) => item.ok).length;
      return json({ sent, failed: results.length - sent, message: sent ? "Ujian notifikasi dihantar." : "Notifikasi ujian gagal dihantar." });
    }

    return json({ error: "Unsupported action" }, 400);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Push subscription operation failed.";
    console.error("manage-admin-push-subscription error", message);
    return json({ error: message }, 500);
  }
});
