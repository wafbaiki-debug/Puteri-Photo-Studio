-- Puteri Photo Studio: bootstrap the single owner admin account.
-- 1) Create the owner account manually in Supabase Authentication -> Users.
-- 2) Copy that user's UUID.
-- 3) Replace OWNER_AUTH_USER_UUID below with the real UUID and run this script.
-- This script intentionally leaves only that one account in public.admin_users.

begin;

delete from public.admin_users
where user_id <> 'OWNER_AUTH_USER_UUID'::uuid;

insert into public.admin_users (user_id)
values ('OWNER_AUTH_USER_UUID'::uuid)
on conflict (user_id) do nothing;

commit;
