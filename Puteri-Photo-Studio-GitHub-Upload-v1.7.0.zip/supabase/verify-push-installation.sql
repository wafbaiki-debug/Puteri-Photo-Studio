-- Read-only checks for Puteri Photo Studio admin push notifications.
select to_regclass('public.admin_push_subscriptions') as subscriptions_table,
       to_regclass('public.admin_push_notification_log') as notification_log_table;

select c.relname as table_name, c.relrowsecurity as rls_enabled
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public'
  and c.relname in ('admin_push_subscriptions', 'admin_push_notification_log')
order by c.relname;

select pubname, schemaname, tablename
from pg_publication_tables
where pubname = 'supabase_realtime'
  and schemaname = 'public'
  and tablename = 'bookings';

select status, count(*) as events, max(created_at) as latest_event
from public.admin_push_notification_log
group by status
order by status;

select count(*) as registered_admin_devices, max(last_seen_at) as latest_device_seen
from public.admin_push_subscriptions;
