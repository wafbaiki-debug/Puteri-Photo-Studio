-- Read-only production readiness checks for Puteri Photo Studio.
-- Run after schema/migrations and owner bootstrap.

select 'studio_settings' as check_name,
       case when exists (select 1 from public.studio_settings where id = true) then 'OK' else 'MISSING' end as result;

select 'manual_maybank_details' as check_name,
       case when exists (
         select 1 from public.studio_settings
         where id = true and bank_name = 'Maybank'
           and bank_account_name = 'Puteri Norsyahira Natasya Binti Suhami'
           and bank_account_number = '162786160739'
       ) then 'OK' else 'CHECK SETTINGS' end as result;

select 'active_packages' as check_name, count(*)::text || ' active package(s)' as result
from public.packages where active = true;

select 'owner_admin_count' as check_name, count(*)::text || ' admin user(s)' as result
from public.admin_users;

select 'bookings_rls' as check_name,
       case when (select relrowsecurity from pg_class where oid = 'public.bookings'::regclass) then 'ENABLED' else 'DISABLED' end as result;

select 'push_subscription_table' as check_name,
       case when to_regclass('public.admin_push_subscriptions') is not null then 'OK' else 'MISSING' end as result;

select 'push_log_table' as check_name,
       case when to_regclass('public.admin_push_notification_log') is not null then 'OK' else 'MISSING' end as result;

select 'fiuu_payments_table' as check_name,
       case when to_regclass('public.fiuu_payments') is not null then 'OK' else 'MISSING' end as result;

select 'realtime_bookings' as check_name,
       case when exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'bookings') then 'ENABLED' else 'CHECK PUBLICATION' end as result;
