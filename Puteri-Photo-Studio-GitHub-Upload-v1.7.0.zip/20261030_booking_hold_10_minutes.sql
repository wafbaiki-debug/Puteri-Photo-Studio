-- Puteri Suhaimi Photo Studio: set unpaid booking holds to 10 minutes.
-- Run once in the existing Supabase project after the v1.5.0 operating-hours migration.
-- Keeps the approved normal and Ramadan operating-hour validation unchanged.
-- Replaces public.create_booking so the database releases unpaid slots after 10 minutes.

begin;

create or replace function public.create_booking(
  p_customer_name text,
  p_customer_phone text,
  p_customer_email text,
  p_package_id uuid,
  p_start_at timestamptz,
  p_customer_note text default null
)
returns table (
  id uuid,
  booking_code text,
  start_at timestamptz,
  end_at timestamptz,
  amount numeric,
  hold_expires_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_package public.packages%rowtype;
  v_settings public.studio_settings%rowtype;
  v_local_start timestamp without time zone;
  v_local_date date;
  v_local_time time;
  v_open_at timestamptz;
  v_morning_close_at timestamptz;
  v_afternoon_open_at timestamptz;
  v_day_close_at timestamptz;
  v_evening_open_at timestamptz;
  v_close_at timestamptz;
  v_ramadan_morning_open_at timestamptz;
  v_ramadan_morning_close_at timestamptz;
  v_ramadan_afternoon_open_at timestamptz;
  v_ramadan_afternoon_close_at timestamptz;
  v_end_at timestamptz;
  v_is_ramadan boolean;
begin
  perform public.expire_booking_holds();

  if coalesce(length(trim(p_customer_name)), 0) < 2 or length(trim(p_customer_name)) > 100 then
    raise exception 'Sila masukkan nama pelanggan yang sah.' using errcode = '22023';
  end if;
  if coalesce(length(trim(p_customer_phone)), 0) < 8 or length(trim(p_customer_phone)) > 30 then
    raise exception 'Sila masukkan nombor telefon yang sah.' using errcode = '22023';
  end if;
  if p_start_at is null or p_start_at <= now() then
    raise exception 'Masa tempahan mesti pada masa hadapan.' using errcode = '22023';
  end if;
  if p_start_at <> date_trunc('minute', p_start_at) then
    raise exception 'Masa mula mesti tepat pada minit.' using errcode = '22023';
  end if;

  select * into v_package
    from public.packages p
   where p.id = p_package_id and p.active = true;
  if not found then
    raise exception 'Pakej tidak aktif atau tidak ditemui.' using errcode = '22023';
  end if;

  select * into v_settings from public.studio_settings where id = true;
  if not found then
    raise exception 'Tetapan studio belum disediakan.' using errcode = '55000';
  end if;

  v_local_start := p_start_at at time zone 'Asia/Kuala_Lumpur';
  v_local_date := v_local_start::date;
  v_local_time := v_local_start::time;

  if extract(minute from v_local_start)::integer % 15 <> 0 or extract(second from v_local_start) <> 0 then
    raise exception 'Masa mula mestilah pada sela 15 minit.' using errcode = '22023';
  end if;

  v_is_ramadan := v_settings.ramadan_start is not null
      and v_settings.ramadan_end is not null
      and v_local_date between v_settings.ramadan_start and v_settings.ramadan_end;

  v_close_at := ((v_local_date + 1)::timestamp without time zone) at time zone 'Asia/Kuala_Lumpur';
  v_end_at := p_start_at + make_interval(mins => v_package.duration_minutes);

  if v_is_ramadan then
    v_ramadan_morning_open_at := (v_local_date + time '09:00') at time zone 'Asia/Kuala_Lumpur';
    v_ramadan_morning_close_at := (v_local_date + time '12:30') at time zone 'Asia/Kuala_Lumpur';
    v_ramadan_afternoon_open_at := (v_local_date + time '14:00') at time zone 'Asia/Kuala_Lumpur';
    v_ramadan_afternoon_close_at := (v_local_date + time '18:00') at time zone 'Asia/Kuala_Lumpur';

    if not (
      (p_start_at >= v_ramadan_morning_open_at and v_end_at <= v_ramadan_morning_close_at)
      or
      (p_start_at >= v_ramadan_afternoon_open_at and v_end_at <= v_ramadan_afternoon_close_at)
    ) then
      raise exception 'Untuk tarikh Ramadan, sesi hanya dibenarkan dari 9:00 pagi hingga 12:30 tengah hari dan 2:00 petang hingga 6:00 petang. Rehat 12:30 hingga 2:00 petang.' using errcode = '22023';
    end if;
  else
    v_open_at := (v_local_date + time '09:00') at time zone 'Asia/Kuala_Lumpur';
    v_morning_close_at := (v_local_date + time '12:00') at time zone 'Asia/Kuala_Lumpur';
    v_afternoon_open_at := (v_local_date + time '14:00') at time zone 'Asia/Kuala_Lumpur';
    v_day_close_at := (v_local_date + time '18:00') at time zone 'Asia/Kuala_Lumpur';
    v_evening_open_at := (v_local_date + time '20:00') at time zone 'Asia/Kuala_Lumpur';
    if not (
      (p_start_at >= v_open_at and v_end_at <= v_morning_close_at)
      or (p_start_at >= v_afternoon_open_at and v_end_at <= v_day_close_at)
      or (p_start_at >= v_evening_open_at and v_end_at <= v_close_at)
    ) then
      raise exception 'Waktu sesi biasa ialah 9:00 pagi–12:00 tengah hari, 2:00–6:00 petang dan 8:00 malam–12:00 tengah malam. Waktu rehat 12:00–2:00 petang dan 6:00–8:00 malam.' using errcode = '22023';
    end if;
  end if;

  return query
    insert into public.bookings as b (
      customer_name, customer_phone, customer_email, customer_note,
      package_id, package_name, duration_minutes, amount,
      start_at, end_at, status, hold_expires_at
    ) values (
      trim(p_customer_name), trim(p_customer_phone), nullif(trim(coalesce(p_customer_email, '')), ''), nullif(trim(coalesce(p_customer_note, '')), ''),
      v_package.id, v_package.name, v_package.duration_minutes, v_package.price,
      p_start_at, v_end_at, 'awaiting_payment', now() + interval '10 minutes'
    )
    returning b.id, b.booking_code, b.start_at, b.end_at, b.amount, b.hold_expires_at;
end;
$$;

grant execute on function public.create_booking(text, text, text, uuid, timestamptz, text) to anon, authenticated;

commit;

-- Verify the installed function definition and existing booking packages.
select p.proname, pg_get_function_identity_arguments(p.oid) as arguments
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname = 'create_booking';
