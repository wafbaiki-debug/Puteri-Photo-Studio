# Puteri Photo Studio - Admin Push Notifications

This build uses browser push notifications for the admin because the studio has one WhatsApp number only (`01167696395`). It does not attempt to send WhatsApp messages from the studio number back to itself.

## What the admin receives

- New booking inserted.
- Manual Maybank receipt submitted.
- Fiuu payment confirmed.
- Payment requiring admin review.
- Booking cancelled.
- Payment failed or booking hold expired.

The admin can subscribe more than one device (for example, Android phone and desktop). Each device must enable notifications separately. Supabase Realtime refreshes the dashboard while the admin page is open; Web Push can notify the subscribed device when the app is in the background, subject to browser and operating-system support.

## Requirements

- The app must be published on HTTPS.
- Supabase project and Fiuu migration must already be configured.
- Admin must log in using the owner account in `public.admin_users`.
- The admin opens the PWA on the device and presses **Aktifkan notifikasi** once.
- Android: Chrome is recommended; installing the PWA to the home screen is recommended.
- iPhone/iPad: Web Push requires iOS/iPadOS 16.4 or later and the web app added to the Home Screen. Open the installed Home Screen app before enabling notifications.
- Browser notification permission must be allowed. Battery saver, focus modes, or OS notification settings may delay or suppress display.

## 1. Apply the database migration

For an existing Puteri Photo Studio database, run this once in Supabase SQL Editor:

`supabase/migrations/20261030_admin_push_notifications.sql`

For a brand-new database, use the updated root `schema.sql` instead. Do not run both unless you are intentionally reconciling a database.

The migration creates:

- `public.admin_push_subscriptions` - private push endpoints registered by the owner devices.
- `public.admin_push_notification_log` - delivery and error log.

Both tables have RLS enabled and are inaccessible to `anon` and `authenticated`; Edge Functions use the service-role key server-side.

## 2. Generate VAPID keys

Generate a VAPID public/private key pair locally. With Node.js installed, run:

```sh
npx web-push generate-vapid-keys
```

Keep the private key secret. The public key is safe to place in the browser configuration. Do not paste the private key into this chat or commit it to Git.

## 3. Configure the public browser key

In `index.html`, update the existing `window.STUDIO_CONFIG` object:

```js
window.STUDIO_CONFIG = {
  supabaseUrl: "https://YOUR_PROJECT_REF.supabase.co",
  supabaseAnonKey: "YOUR_PUBLIC_ANON_OR_PUBLISHABLE_KEY",
  pushVapidPublicKey: "YOUR_VAPID_PUBLIC_KEY",
  demoMode: false
};
```

Use the Supabase public anon/publishable key only. Never put the Supabase service-role key or VAPID private key in the browser.

## 4. Set Supabase Edge Function secrets

Set these in Supabase Dashboard -> Edge Functions -> Secrets, or with the Supabase CLI:

```sh
supabase secrets set \
  PUSH_VAPID_PUBLIC_KEY="YOUR_VAPID_PUBLIC_KEY" \
  PUSH_VAPID_PRIVATE_KEY="YOUR_VAPID_PRIVATE_KEY" \
  PUSH_VAPID_SUBJECT="mailto:YOUR_CONTACT_EMAIL" \
  PUSH_WEBHOOK_SECRET="A_LONG_RANDOM_SECRET"
```

`SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` are supplied by the Supabase Edge Function environment. If your project does not expose `SUPABASE_ANON_KEY` automatically, set it as an Edge Function secret using the public anon/publishable key.

## 5. Deploy the Edge Functions

From the project root:

```sh
supabase functions deploy manage-admin-push-subscription
supabase functions deploy notify-admin-push
```

`manage-admin-push-subscription` requires a valid admin login (JWT verification enabled). `notify-admin-push` is a server-to-server Database Webhook and verifies the separate `PUSH_WEBHOOK_SECRET` header.

## 6. Configure the Supabase Database Webhook

In Supabase Dashboard -> Database -> Webhooks, create:

- Name: `pps_admin_push_notifications`
- Table: `public.bookings`
- Events: `INSERT` and `UPDATE`
- Method: `POST`
- URL: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/notify-admin-push`
- Header `Content-Type`: `application/json`
- Header `x-webhook-secret`: the same value as `PUSH_WEBHOOK_SECRET`

The function filters booking changes and ignores updates that do not require a notification. Do not create a webhook for `fiuu_payments`; successful Fiuu processing updates the booking row and triggers this webhook.

## 7. Enable notifications on the admin phone

1. Publish the app on HTTPS and open it in Chrome on the admin phone.
2. Install the PWA / Add to Home Screen if available.
3. Log in as the owner in the Admin Dashboard.
4. Press **Aktifkan notifikasi** and allow browser notifications.
5. Press **Uji notifikasi**. A test notification should arrive on that device.
6. Repeat on any other admin device that should receive alerts.

The app saves the push subscription against the authenticated owner account. Logging out does not remove the device subscription. Use **Matikan notifikasi** on that device to unsubscribe it.

## 8. Realtime dashboard and acceptance tests

The app subscribes to `public.bookings` while the owner is logged in. The migration attempts to add the table to `supabase_realtime` if the publication exists. If the dashboard status does not show `Dashboard live: disambungkan`, verify Database -> Publications / Realtime includes `public.bookings` and that the authenticated owner can select booking rows under RLS.

Test all of the following:

- Create a test booking: dashboard refreshes and push arrives.
- Upload a manual receipt: push says receipt received; booking remains pending verification.
- Complete a Fiuu sandbox payment: push says payment confirmed only after the verified server callback updates the booking.
- Cancel a booking: push arrives.
- Disable notifications on one device: that device no longer receives pushes; other subscribed devices still do.
- Check `admin_push_notification_log` for `sent`, `partial`, `failed`, or `no_subscribers`.

## Important limitations

- Push notifications require HTTPS, a registered service worker, permission from the user, a valid VAPID key pair, and deployed Supabase functions/webhook.
- Push delivery is best-effort; operating-system focus modes, browser policies, network conditions, or expired subscriptions can delay or suppress a notification. The Admin Dashboard remains the authoritative record.
- One WhatsApp number (`01167696395`) remains for customer enquiries and customer communication. Admin alerts are delivered to subscribed devices, not WhatsApp.
- The app has not been deployed to production and no real push notification can be sent until the owner completes the Supabase and HTTPS setup above.
