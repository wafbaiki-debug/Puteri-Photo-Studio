# Puteri Suhaimi Photo Studio v1.7.0 - Manual Maybank Payment

This source package provides the responsive customer and admin PWA. The customer checkout uses **Maybank manual transfer only**. No Fiuu merchant credentials are required.

## Customer app

- Package selection: PUTERI RM140/15 min, MARYAM RM170/30 min, PREMIUM RM330/60 min.
- Date/time selection with past-time filtering and database overlap protection.
- Ten-minute unpaid hold.
- Maybank transfer instructions and receipt upload (JPG/PNG/WEBP/PDF, max 5 MB).
- Booking code and WhatsApp follow-up link.

## Admin app

- Supabase Auth login plus `admin_users` allow-list.
- Booking list, filters/search, receipt review, confirm/cancel/complete actions.
- Package management, calendar, studio/bank settings and Ramadan dates.
- Realtime and push notification support when server-side push setup is complete.

## PWA installation

- Android: Chrome > menu > Install app / Add to Home screen.
- iOS/iPadOS: Safari > Share > Add to Home Screen.

This is a PWA and requires internet for Supabase booking and receipt uploads.

## Deployment

Use the repository bundle v1.7.0. Vercel build variables required: `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and optionally `VAPID_PUBLIC_KEY`. The build wrapper creates `config.js` from those values. Never commit private keys.

For the existing live database, do not run `schema.sql` or old migrations again without checking whether they were already applied. The current project has already verified the 10-minute hold and past-time validation.
