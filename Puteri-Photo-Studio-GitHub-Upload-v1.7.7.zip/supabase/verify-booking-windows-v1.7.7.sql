-- READ ONLY: run after migration to inspect stored booking durations and intervals.
SELECT
  b.booking_code,
  b.package_name,
  b.status,
  b.duration_minutes AS saved_minutes,
  p.duration_minutes AS current_package_minutes,
  to_char(b.start_at AT TIME ZONE 'Asia/Kuala_Lumpur','YYYY-MM-DD HH24:MI') AS local_start,
  to_char(b.end_at AT TIME ZONE 'Asia/Kuala_Lumpur','YYYY-MM-DD HH24:MI') AS local_end,
  ROUND(EXTRACT(EPOCH FROM (b.end_at - b.start_at))/60) AS saved_interval_minutes,
  CASE
    WHEN b.duration_minutes <> EXTRACT(EPOCH FROM (b.end_at - b.start_at))/60 THEN 'CHECK INTERVAL'
    WHEN b.status IN ('awaiting_payment','pending_verification','confirmed')
         AND p.duration_minutes IS NOT NULL AND b.duration_minutes < p.duration_minutes THEN 'CHECK PACKAGE DURATION'
    ELSE 'OK'
  END AS audit_result
FROM public.bookings b
LEFT JOIN public.packages p ON p.id = b.package_id
WHERE b.start_at >= now()-interval '30 days'
ORDER BY b.start_at DESC
LIMIT 100;

SELECT jobname,schedule,active FROM cron.job WHERE jobname='puteri-photo-expire-unpaid-holds';
