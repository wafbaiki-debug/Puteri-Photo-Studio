import { createClient } from "npm:@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { "content-type": "application/json; charset=utf-8" },
});
function requiredEnv(name: string): string {
  const value = Deno.env.get(name)?.trim();
  if (!value) throw new Error(`Missing Edge Function secret: ${name}`);
  return value;
}
function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
function detectEvent(type: string, record: Record<string, unknown>, old: Record<string, unknown>) {
  // Manual-payment workflow: notify the owner only when a customer submits a receipt.
  // An unpaid booking INSERT is a temporary 10-minute hold, not a real booking.
  if (type !== "UPDATE") return null;
  const status = String(record.status || "");
  const oldStatus = String(old.status || "");
  if (
    status === "pending_verification" &&
    oldStatus !== "pending_verification" &&
    record.payment_method === "manual_transfer" &&
    Boolean(record.receipt_path)
  ) return "manual_receipt_received";
  return null;
}
const labels: Record<string, string> = {
  manual_receipt_received: "Resit Maybank diterima - semak duit masuk",
};
function dateTime(value: unknown): string {
  if (!value) return "Masa belum ditetapkan";
  const date = new Date(String(value));
  if (Number.isNaN(date.getTime())) return "Masa belum ditetapkan";
  return new Intl.DateTimeFormat("ms-MY", {
    timeZone: "Asia/Kuala_Lumpur", day: "2-digit", month: "short", year: "numeric",
    hour: "2-digit", minute: "2-digit", hour12: true,
  }).format(date);
}

Deno.serve(async (request: Request) => {
  if (request.method !== "POST") return json({ error: "Method not allowed" }, 405);
  let logId: string | null = null;
  try {
    const secret = requiredEnv("PUSH_WEBHOOK_SECRET");
    const supplied = request.headers.get("x-webhook-secret") || "";
    if (!constantTimeEqual(secret, supplied)) return json({ error: "Unauthorized webhook" }, 401);

    const payload = await request.json();
    if (payload?.schema !== "public" || payload?.table !== "bookings") return json({ ignored: true });
    const record = (payload.record || {}) as Record<string, unknown>;
    const old = (payload.old_record || {}) as Record<string, unknown>;
    if (!record.id || !record.booking_code) return json({ error: "Booking record is incomplete" }, 400);
    const eventType = detectEvent(String(payload.type || ""), record, old);
    if (!eventType) return json({ ignored: true, reason: "No notification-worthy booking change" });

    const supabaseUrl = requiredEnv("SUPABASE_URL");
    const serviceRoleKey = requiredEnv("SUPABASE_SERVICE_ROLE_KEY");
    const db = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false } });
    const eventStamp = String(record.updated_at || record.created_at || "unknown");
    const eventKey = `${String(record.id)}:${eventType}:${eventStamp}`;
    const { data: inserted, error: insertError } = await db.from("admin_push_notification_log").insert({
      event_key: eventKey, booking_id: String(record.id), event_type: eventType, status: "processing", attempts: 1,
    }).select("id").single();
    if (insertError) {
      if (insertError.code !== "23505") throw insertError;
      const { data: existing, error: lookupError } = await db.from("admin_push_notification_log")
        .select("id,status,attempts").eq("event_key", eventKey).maybeSingle();
      if (lookupError) throw lookupError;
      if (!existing) throw new Error("Unable to inspect duplicate push event.");
      if (existing.status !== "failed") return json({ ok: true, skipped: true, reason: `Notification already ${existing.status}` });
      const { data: retry, error: retryError } = await db.from("admin_push_notification_log")
        .update({ status: "processing", attempts: Number(existing.attempts || 1) + 1, error_message: null, updated_at: new Date().toISOString() })
        .eq("id", existing.id).eq("status", "failed").select("id").maybeSingle();
      if (retryError) throw retryError;
      if (!retry) return json({ ok: true, skipped: true, reason: "Retry already claimed" });
      logId = String(retry.id);
    } else {
      logId = String(inserted.id);
    }

    webpush.setVapidDetails(requiredEnv("PUSH_VAPID_SUBJECT"), requiredEnv("PUSH_VAPID_PUBLIC_KEY"), requiredEnv("PUSH_VAPID_PRIVATE_KEY"));
    const { data: subscriptions, error: subscriptionError } = await db.from("admin_push_subscriptions")
      .select("id,endpoint,subscription");
    if (subscriptionError) throw subscriptionError;
    if (!subscriptions?.length) {
      await db.from("admin_push_notification_log").update({ status: "no_subscribers", updated_at: new Date().toISOString() }).eq("id", logId);
      return json({ ok: true, sent: 0, reason: "No admin devices are subscribed" });
    }

    const bookingCode = String(record.booking_code);
    const packageName = String(record.package_name || "Pakej studio");
    const amount = `RM ${Number(record.amount || 0).toFixed(2)}`;
    const customerName = String(record.customer_name || "Pelanggan");
    const body = `${customerName} · ${bookingCode} · ${packageName} · ${dateTime(record.start_at)} · ${amount}. Resit diterima; semak transaksi Maybank sebelum sahkan.`;
    const notification = {
      title: `Puteri Photo Studio: ${labels[eventType]}`,
      body: body.slice(0, 220),
      tag: `pps-${bookingCode}-${eventType}`,
      url: "./index.html?admin=1",
      icon: "./icon.svg",
      badge: "./icon.svg",
    };

    const results = await Promise.all(subscriptions.map(async (row) => {
      try {
        await webpush.sendNotification(row.subscription, JSON.stringify(notification), { TTL: 3600, urgency: "high" });
        return { ok: true };
      } catch (error) {
        const statusCode = Number((error as { statusCode?: number })?.statusCode || 0);
        if (statusCode === 404 || statusCode === 410) {
          await db.from("admin_push_subscriptions").delete().eq("id", row.id);
        }
        return { ok: false, message: error instanceof Error ? error.message : "Push delivery failed" };
      }
    }));
    const sent = results.filter((item) => item.ok).length;
    const failed = results.length - sent;
    const status = sent === 0 ? "failed" : failed ? "partial" : "sent";
    const errorMessage = failed ? results.filter((item) => !item.ok).map((item) => item.message).join("; ").slice(0, 1000) : null;
    const { error: logUpdateError } = await db.from("admin_push_notification_log").update({
      status, sent_count: sent, failed_count: failed, error_message: errorMessage, updated_at: new Date().toISOString(),
    }).eq("id", logId);
    if (logUpdateError) throw logUpdateError;
    return json({ ok: sent > 0, event: eventType, sent, failed });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Push notification failed.";
    console.error("notify-admin-push error", message);
    if (logId) {
      try {
        const url = Deno.env.get("SUPABASE_URL");
        const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
        if (url && key) {
          const db = createClient(url, key, { auth: { persistSession: false } });
          await db.from("admin_push_notification_log").update({ status: "failed", error_message: message.slice(0, 1000), updated_at: new Date().toISOString() }).eq("id", logId);
        }
      } catch (logError) { console.error("Unable to update push notification log", logError); }
    }
    return json({ error: message }, 502);
  }
});
