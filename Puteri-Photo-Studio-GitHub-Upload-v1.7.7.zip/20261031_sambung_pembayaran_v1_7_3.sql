-- Puteri Suhaimi Photo Studio v1.7.3
-- Add public, minimal-data lookup so customers can resume an existing unpaid booking.
-- Safe to run once; does not change bookings, booking holds, payment settings, or receipt files.

begin;


-- Public customer lookup for resuming an existing manual-payment booking.
-- Only minimal booking details are returned; booking id is exposed only while an unpaid hold is active.
create or replace function public.lookup_booking_for_payment(p_lookup text)
returns table (
  id uuid,
  booking_code text,
  package_name text,
  duration_minutes integer,
  amount numeric,
  start_at timestamptz,
  end_at timestamptz,
  status text,
  payment_status text,
  hold_expires_at timestamptz,
  receipt_uploaded_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_lookup text := upper(regexp_replace(trim(coalesce(p_lookup, '')), '\s+', '', 'g'));
  v_digits text := regexp_replace(coalesce(p_lookup, ''), '[^0-9]', '', 'g');
  v_phone text;
begin
  if v_lookup = '' or length(v_lookup) > 60 then
    raise exception 'Masukkan kod tempahan atau nombor telefon yang sah.' using errcode = '22023';
  end if;

  if left(v_digits, 2) = '00' then
    v_digits := substr(v_digits, 3);
  end if;
  if left(v_digits, 1) = '0' then
    v_phone := '60' || substr(v_digits, 2);
  elsif left(v_digits, 2) = '60' then
    v_phone := v_digits;
  elsif length(v_digits) between 9 and 10 then
    v_phone := '60' || v_digits;
  else
    v_phone := v_digits;
  end if;

  perform public.expire_booking_holds();

  return query
    select
      case when b.status = 'awaiting_payment' and b.hold_expires_at > now() then b.id else null::uuid end,
      b.booking_code,
      b.package_name,
      b.duration_minutes,
      b.amount,
      b.start_at,
      b.end_at,
      b.status,
      b.payment_status,
      b.hold_expires_at,
      b.receipt_uploaded_at
    from public.bookings b
    where upper(b.booking_code) = v_lookup
       or (
         length(v_phone) between 9 and 15
         and (
           case
             when left(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g'), 2) = '00'
               then substr(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g'), 3)
             when left(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g'), 1) = '0'
               then '60' || substr(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g'), 2)
             when left(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g'), 2) = '60'
               then regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g')
             when length(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g')) between 9 and 10
               then '60' || regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g')
             else regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g')
           end
         ) = v_phone
       )
    order by b.created_at desc
    limit 10;
end;
$$;

revoke all on function public.lookup_booking_for_payment(text) from public;
grant execute on function public.lookup_booking_for_payment(text) to anon, authenticated;

commit;
