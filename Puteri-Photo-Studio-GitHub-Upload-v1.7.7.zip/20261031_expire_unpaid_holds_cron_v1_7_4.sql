-- Puteri Photo Studio v1.7.4
-- Optional background job: expire unpaid 10-minute holds once per minute.
-- The app's availability/create/lookup RPCs also expire old holds before checking slots.
-- Run this only after pg_cron is enabled for the Supabase project.
-- Safe to run again: replaces this named job instead of creating duplicates.

do $$
declare
  v_job_id bigint;
begin
  if not exists (select 1 from pg_extension where extname = 'pg_cron') then
    raise notice 'pg_cron is not enabled. Enable it in Supabase Database > Extensions, then run this file again.';
    return;
  end if;

  for v_job_id in
    select jobid from cron.job where jobname = 'puteri-photo-expire-unpaid-holds'
  loop
    perform cron.unschedule(v_job_id);
  end loop;

  perform cron.schedule(
    'puteri-photo-expire-unpaid-holds',
    '* * * * *',
    'select public.expire_booking_holds();'
  );
  raise notice 'Scheduled Puteri unpaid booking hold expiry every minute.';
exception
  when undefined_table or undefined_function or invalid_schema_name then
    raise notice 'pg_cron is not ready. Enable the pg_cron extension and run this file again. Existing app-side expiry checks remain active.';
end;
$$;
