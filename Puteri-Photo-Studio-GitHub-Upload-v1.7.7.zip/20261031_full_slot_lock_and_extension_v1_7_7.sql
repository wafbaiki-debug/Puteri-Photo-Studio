-- Puteri Photo Studio v1.7.7: admin-controlled time extension and stronger future-booking checks.
-- APPLY ONCE to existing Supabase database BEFORE publishing the v1.7.7 frontend.
-- No existing bookings, receipts or payment histories are deleted or rewritten.
-- Existing previously-created intervals must be inspected using the supplied diagnostic query.
BEGIN;

-- Leave photography packages at their established 15 / 30 / 60 minutes.
-- A booking may become longer than its original package after the admin confirms a paid extension.
ALTER TABLE public.bookings DROP CONSTRAINT IF EXISTS bookings_duration_minutes_check;
ALTER TABLE public.bookings ADD CONSTRAINT bookings_duration_minutes_check
  CHECK (duration_minutes BETWEEN 15 AND 240 AND duration_minutes % 15 = 0);

-- Do not proceed without a database-level no-overlap constraint: UI disabling alone is not sufficient.
-- Existing projects have this constraint; the fallback below installs it only if missing.
SELECT public.expire_booking_holds();
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.bookings'::regclass AND conname = 'no_overlapping_active_bookings'
  ) THEN
    ALTER TABLE public.bookings
      ADD CONSTRAINT no_overlapping_active_bookings
      EXCLUDE USING gist (tstzrange(start_at, end_at, '[)') WITH &&)
      WHERE (status IN ('awaiting_payment', 'pending_verification', 'confirmed'));
  END IF;
END $$;

-- Log every admin-approved extension and its verified additional bank payment.
CREATE TABLE IF NOT EXISTS public.booking_extensions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES public.bookings(id) ON DELETE RESTRICT,
  additional_minutes integer NOT NULL CHECK (additional_minutes IN (15,30,45,60)),
  old_end_at timestamptz NOT NULL,
  new_end_at timestamptz NOT NULL CHECK (new_end_at > old_end_at),
  additional_amount numeric(10,2) NOT NULL DEFAULT 0 CHECK (additional_amount >= 0),
  approved_by uuid NOT NULL,
  approved_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.booking_extensions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS booking_extensions_admin_read ON public.booking_extensions;
CREATE POLICY booking_extensions_admin_read ON public.booking_extensions
  FOR SELECT TO authenticated USING (public.is_admin());
REVOKE ALL ON public.booking_extensions FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.booking_extensions TO authenticated;

-- Protect creation of new sessions: advertised package duration must be reflected in its locked range.
CREATE OR REPLACE FUNCTION public.ensure_new_booking_full_duration()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_package_duration integer;
BEGIN
  IF NEW.package_id IS NOT NULL THEN
    SELECT duration_minutes INTO v_package_duration
    FROM public.packages WHERE id = NEW.package_id;
    IF v_package_duration IS NULL OR NEW.duration_minutes <> v_package_duration THEN
      RAISE EXCEPTION 'Tempoh tempahan tidak sepadan dengan pakej pilihan.' USING ERRCODE = '22023';
    END IF;
  END IF;
  IF NEW.end_at <> NEW.start_at + make_interval(mins => NEW.duration_minutes) THEN
    RAISE EXCEPTION 'Keseluruhan tempoh pakej mesti ditempah.' USING ERRCODE = '22023';
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS ensure_new_booking_full_duration ON public.bookings;
CREATE TRIGGER ensure_new_booking_full_duration
BEFORE INSERT ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.ensure_new_booking_full_duration();

-- Keep availability driven by the actual reserved time range, not 15-minute button boundaries.
CREATE OR REPLACE FUNCTION public.get_busy_intervals(p_date date)
RETURNS TABLE (start_at timestamptz, end_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.expire_booking_holds();
  RETURN QUERY
    SELECT b.start_at, b.end_at
    FROM public.bookings b
    WHERE (b.start_at AT TIME ZONE 'Asia/Kuala_Lumpur')::date = p_date
      AND b.status IN ('awaiting_payment', 'pending_verification', 'confirmed')
      AND (b.status <> 'awaiting_payment' OR b.hold_expires_at > now())
    ORDER BY b.start_at;
END $$;

CREATE OR REPLACE FUNCTION public.extend_confirmed_booking(
  p_booking_id uuid,
  p_extra_minutes integer,
  p_received_extra_amount numeric DEFAULT 0
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_booking public.bookings%rowtype;
  v_settings public.studio_settings%rowtype;
  v_end timestamptz;
  v_local_date date;
  v_ramadan boolean;
  v_segment_ok boolean := false;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Hanya admin berdaftar dibenarkan meluluskan sambungan masa.' USING ERRCODE = '42501';
  END IF;
  IF p_extra_minutes IS NULL OR p_extra_minutes NOT IN (15,30,45,60) THEN
    RAISE EXCEPTION 'Pilih tambahan 15, 30, 45 atau 60 minit.' USING ERRCODE = '22023';
  END IF;
  IF p_received_extra_amount IS NULL OR p_received_extra_amount < 0 OR p_received_extra_amount > 9999 THEN
    RAISE EXCEPTION 'Jumlah tambahan tidak sah.' USING ERRCODE = '22023';
  END IF;
  IF p_received_extra_amount <> round(p_received_extra_amount, 2) THEN
    RAISE EXCEPTION 'Jumlah bayaran hanya boleh mempunyai 2 tempat perpuluhan.' USING ERRCODE = '22023';
  END IF;
  PERFORM public.expire_booking_holds();
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Tempahan tidak ditemui.' USING ERRCODE = 'P0002';
  END IF;
  IF v_booking.status <> 'confirmed' OR v_booking.payment_status <> 'paid' THEN
    RAISE EXCEPTION 'Sahkan bayaran asal dan tempahan terlebih dahulu sebelum menambah masa.' USING ERRCODE = '55000';
  END IF;
  IF v_booking.end_at <= now() THEN
    RAISE EXCEPTION 'Sesi telah tamat. Sambungan masa tidak boleh dibuat.' USING ERRCODE = '55000';
  END IF;
  IF v_booking.duration_minutes + p_extra_minutes > 240 THEN
    RAISE EXCEPTION 'Jumlah tempoh sesi tidak boleh melebihi 240 minit.' USING ERRCODE = '22023';
  END IF;
  v_end := v_booking.end_at + make_interval(mins => p_extra_minutes);
  v_local_date := (v_booking.start_at AT TIME ZONE 'Asia/Kuala_Lumpur')::date;
  SELECT * INTO v_settings FROM public.studio_settings WHERE id = true;
  IF NOT FOUND THEN RAISE EXCEPTION 'Tetapan studio belum disediakan.' USING ERRCODE = '55000'; END IF;
  v_ramadan := v_settings.ramadan_start IS NOT NULL AND v_settings.ramadan_end IS NOT NULL
    AND v_local_date BETWEEN v_settings.ramadan_start AND v_settings.ramadan_end;
  IF v_ramadan THEN
    v_segment_ok := (
      (v_booking.start_at >= (v_local_date + time '09:00') AT TIME ZONE 'Asia/Kuala_Lumpur' AND v_end <= (v_local_date + time '12:30') AT TIME ZONE 'Asia/Kuala_Lumpur')
      OR (v_booking.start_at >= (v_local_date + time '14:00') AT TIME ZONE 'Asia/Kuala_Lumpur' AND v_end <= (v_local_date + time '18:00') AT TIME ZONE 'Asia/Kuala_Lumpur')
    );
  ELSE
    v_segment_ok := (
      (v_booking.start_at >= (v_local_date + time '09:00') AT TIME ZONE 'Asia/Kuala_Lumpur' AND v_end <= (v_local_date + time '12:00') AT TIME ZONE 'Asia/Kuala_Lumpur')
      OR (v_booking.start_at >= (v_local_date + time '14:00') AT TIME ZONE 'Asia/Kuala_Lumpur' AND v_end <= (v_local_date + time '18:00') AT TIME ZONE 'Asia/Kuala_Lumpur')
      OR (v_booking.start_at >= (v_local_date + time '20:00') AT TIME ZONE 'Asia/Kuala_Lumpur' AND v_end <= ((v_local_date+1)::timestamp AT TIME ZONE 'Asia/Kuala_Lumpur'))
    );
  END IF;
  IF NOT v_segment_ok THEN
    RAISE EXCEPTION 'Masa tambahan melepasi waktu operasi atau waktu rehat studio.' USING ERRCODE = '22023';
  END IF;
  IF EXISTS (
    SELECT 1 FROM public.bookings other
    WHERE other.id <> v_booking.id
      AND other.status IN ('awaiting_payment','pending_verification','confirmed')
      AND (other.status <> 'awaiting_payment' OR other.hold_expires_at > now())
      AND tstzrange(other.start_at, other.end_at, '[)') && tstzrange(v_booking.end_at, v_end, '[)')
  ) THEN
    RAISE EXCEPTION 'Slot tambahan sudah ditempah / dipegang. Pilih masa lain.' USING ERRCODE = '23P01';
  END IF;
  -- Database exclusion constraint also protects concurrent writes from other customers/admins.
  BEGIN
    UPDATE public.bookings
    SET duration_minutes = v_booking.duration_minutes + p_extra_minutes,
        end_at = v_end,
        amount = v_booking.amount + p_received_extra_amount,
        updated_at = now()
    WHERE id = v_booking.id;
  EXCEPTION WHEN exclusion_violation THEN
    RAISE EXCEPTION 'Slot tambahan baru sahaja diambil pelanggan lain. Tidak dapat meluluskan sambungan.' USING ERRCODE = '23P01';
  END;
  INSERT INTO public.booking_extensions(
    booking_id, additional_minutes, old_end_at, new_end_at, additional_amount, approved_by
  ) VALUES (v_booking.id, p_extra_minutes, v_booking.end_at, v_end, p_received_extra_amount, auth.uid());
  RETURN jsonb_build_object('booking_code', v_booking.booking_code,
    'new_end_at', v_end, 'new_duration_minutes', v_booking.duration_minutes + p_extra_minutes,
    'total_amount', v_booking.amount + p_received_extra_amount);
END;
$$;
REVOKE ALL ON FUNCTION public.extend_confirmed_booking(uuid,integer,numeric) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.extend_confirmed_booking(uuid,integer,numeric) TO authenticated;
COMMIT;
