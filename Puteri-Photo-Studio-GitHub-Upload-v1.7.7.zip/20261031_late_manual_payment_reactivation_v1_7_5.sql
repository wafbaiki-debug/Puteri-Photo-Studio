-- Puteri Photo Studio v1.7.5: allow late full-payment receipt submission when the slot is still free.
-- Run once in Supabase SQL Editor on the existing booking database.
-- This also creates/updates lookup_booking_for_payment and supersedes the v1.7.3 lookup-only migration.
-- Does not delete or overwrite existing bookings or receipt files.

begin;

-- Receipt submission can reactivate an expired unpaid booking only if its future slot is still free.
-- Once a receipt is accepted, pending_verification is excluded from the 10-minute expiry job and keeps the slot blocked.
create or replace function public.submit_booking_receipt(p_booking_id uuid, p_receipt_path text)
returns table (booking_code text, status text, receipt_uploaded_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_booking public.bookings%rowtype;
begin
  perform public.expire_booking_holds();

  if p_receipt_path is null or p_receipt_path not like (p_booking_id::text || '/%') then
    raise exception 'Laluan fail resit tidak sah.' using errcode = '22023';
  end if;

  select * into v_booking
    from public.bookings
   where id = p_booking_id
   for update;

  if not found then
    raise exception 'Tempahan tidak ditemui.' using errcode = 'P0002';
  end if;

  if v_booking.status not in ('awaiting_payment', 'expired')
     or v_booking.receipt_path is not null
     or v_booking.receipt_uploaded_at is not null then
    raise exception 'Tempahan ini tidak lagi menerima resit. Semak status tempahan atau hubungi studio.' using errcode = '55000';
  end if;

  if v_booking.status = 'awaiting_payment'
     and (v_booking.hold_expires_at is null or v_booking.hold_expires_at <= now()) then
    update public.bookings
       set status = 'expired', payment_status = 'expired', hold_expires_at = null, updated_at = now()
     where id = p_booking_id;
    v_booking.status := 'expired';
    v_booking.payment_status := 'expired';
    v_booking.hold_expires_at := null;
  end if;

  if v_booking.start_at <= now() then
    raise exception 'Masa sesi telah berlalu. Tempahan ini tidak boleh diaktifkan semula.' using errcode = '55000';
  end if;

  if exists (
    select 1
      from public.bookings other
     where other.id <> p_booking_id
       and other.status in ('awaiting_payment', 'pending_verification', 'confirmed')
       and (other.status <> 'awaiting_payment' or other.hold_expires_at > now())
       and tstzrange(other.start_at, other.end_at, '[)') && tstzrange(v_booking.start_at, v_booking.end_at, '[)')
  ) then
    raise exception 'Slot ini telah diambil oleh pelanggan lain selepas pegangan awal tamat. Resit belum diterima oleh sistem. Sila hubungi studio untuk bantuan pembayaran.' using errcode = '23P01';
  end if;

  begin
    return query
      update public.bookings as b
         set status = 'pending_verification',
             payment_method = 'manual_transfer',
             payment_status = 'manual_pending',
             receipt_path = p_receipt_path,
             receipt_uploaded_at = now(),
             hold_expires_at = null,
             updated_at = now()
       where b.id = p_booking_id
         and b.status in ('awaiting_payment', 'expired')
         and b.receipt_path is null
         and b.start_at > now()
      returning b.booking_code, b.status, b.receipt_uploaded_at;
  exception
    when exclusion_violation then
      raise exception 'Slot ini telah diambil oleh pelanggan lain. Sila hubungi studio untuk bantuan pembayaran atau pilihan masa lain.' using errcode = '23P01';
  end;

  if not found then
    raise exception 'Tempahan tidak dapat disambung. Sila cari semula menggunakan kod tempahan atau nombor telefon.' using errcode = '55000';
  end if;
end;
$$;

revoke all on function public.submit_booking_receipt(uuid, text) from public;
grant execute on function public.submit_booking_receipt(uuid, text) to anon, authenticated;

-- Public customer lookup for resuming an active hold or submitting a late full-payment receipt.
-- The booking id is returned for an expired booking only while its future slot is still free.
create or replace function public.lookup_booking_for_payment(p_lookup text)
returns table (
  id uuid,
  booking_code text,
  package_name text,
  duration_minutes integer,
  amount numeric,
  start_at timestamptz,
  end_at timestamptz,
  status text,
  payment_status text,
  hold_expires_at timestamptz,
  receipt_uploaded_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_lookup text := upper(regexp_replace(trim(coalesce(p_lookup, '')), '\s+', '', 'g'));
  v_digits text := regexp_replace(coalesce(p_lookup, ''), '[^0-9]', '', 'g');
  v_phone text;
begin
  if v_lookup = '' or length(v_lookup) > 60 then
    raise exception 'Masukkan kod tempahan atau nombor telefon yang sah.' using errcode = '22023';
  end if;

  if left(v_digits, 2) = '00' then
    v_digits := substr(v_digits, 3);
  end if;
  if left(v_digits, 1) = '0' then
    v_phone := '60' || substr(v_digits, 2);
  elsif left(v_digits, 2) = '60' then
    v_phone := v_digits;
  elsif length(v_digits) between 9 and 10 then
    v_phone := '60' || v_digits;
  else
    v_phone := v_digits;
  end if;

  perform public.expire_booking_holds();

  return query
    select
      case
        when b.status = 'awaiting_payment'
          and b.receipt_path is null
          and b.receipt_uploaded_at is null
          and b.hold_expires_at > now()
          and b.start_at > now()
          then b.id
        when b.status = 'expired'
          and b.receipt_path is null
          and b.receipt_uploaded_at is null
          and b.start_at > now()
          and not exists (
            select 1
              from public.bookings other
             where other.id <> b.id
               and other.status in ('awaiting_payment', 'pending_verification', 'confirmed')
               and (other.status <> 'awaiting_payment' or other.hold_expires_at > now())
               and tstzrange(other.start_at, other.end_at, '[)') && tstzrange(b.start_at, b.end_at, '[)')
          )
          then b.id
        else null::uuid
      end,
      b.booking_code,
      b.package_name,
      b.duration_minutes,
      b.amount,
      b.start_at,
      b.end_at,
      b.status,
      b.payment_status,
      b.hold_expires_at,
      b.receipt_uploaded_at
    from public.bookings b
    where upper(b.booking_code) = v_lookup
       or (
         length(v_phone) between 9 and 15
         and (
           case
             when left(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g'), 2) = '00'
               then substr(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g'), 3)
             when left(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g'), 1) = '0'
               then '60' || substr(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g'), 2)
             when left(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g'), 2) = '60'
               then regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g')
             when length(regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g')) between 9 and 10
               then '60' || regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g')
             else regexp_replace(coalesce(b.customer_phone, ''), '[^0-9]', '', 'g')
           end
         ) = v_phone
       )
    order by b.created_at desc
    limit 10;
end;
$$;

revoke all on function public.lookup_booking_for_payment(text) from public;
grant execute on function public.lookup_booking_for_payment(text) to anon, authenticated;

-- Permit storage upload for active holds and expired bookings whose future slot is still free.
create or replace function public.can_upload_receipt(p_booking_id_text text)
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_booking_id uuid;
begin
  if p_booking_id_text is null or p_booking_id_text !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
    return false;
  end if;
  v_booking_id := p_booking_id_text::uuid;

  return exists (
    select 1
      from public.bookings b
     where b.id = v_booking_id
       and b.start_at > now()
       and b.receipt_path is null
       and b.receipt_uploaded_at is null
       and (
         (b.status = 'awaiting_payment' and b.hold_expires_at > now())
         or (b.status = 'awaiting_payment' and b.hold_expires_at <= now() and b.payment_status in ('unpaid', 'pending', 'failed', 'expired'))
         or (b.status = 'expired' and b.payment_status = 'expired')
       )
       and not exists (
         select 1
           from public.bookings other
          where other.id <> b.id
            and other.status in ('awaiting_payment', 'pending_verification', 'confirmed')
            and (other.status <> 'awaiting_payment' or other.hold_expires_at > now())
            and tstzrange(other.start_at, other.end_at, '[)') && tstzrange(b.start_at, b.end_at, '[)')
       )
  );
end;
$$;

revoke all on function public.can_upload_receipt(text) from public;
grant execute on function public.can_upload_receipt(text) to anon, authenticated;

commit;
